import logging
import os
import re
import secrets
import string
from datetime import date, datetime, timezone
from pathlib import Path
from typing import List, Optional

from dotenv import load_dotenv
from fastapi import FastAPI, APIRouter
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, EmailStr, Field, field_validator
from starlette.middleware.cors import CORSMiddleware

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]

app = FastAPI()
api_router = APIRouter(prefix="/api")

PHONE_RE = re.compile(r"^[\d\s()+\-.]{7,20}$")


def gen_reference() -> str:
    alphabet = string.ascii_uppercase + string.digits
    return "RH-" + "".join(secrets.choice(alphabet) for _ in range(6))


def check_phone(v: str) -> str:
    if not PHONE_RE.match(v.strip()) or len(re.sub(r"\D", "", v)) < 10:
        raise ValueError("invalid phone number")
    return v.strip()


def check_not_past(v: date) -> date:
    if v < date.today():
        raise ValueError("date must not be in the past")
    return v


class BookingIn(BaseModel):
    fullName: str = Field(min_length=1, max_length=200)
    phone: str = Field(min_length=1, max_length=30)
    email: EmailStr
    propertyAddress: str = Field(min_length=1, max_length=300)
    cityZip: str = Field(min_length=1, max_length=120)
    propertyType: str = Field(min_length=1, max_length=60)
    squareFootage: Optional[int] = Field(default=None, ge=0, le=100000)
    yearBuilt: Optional[int] = Field(default=None, ge=1600, le=2100)
    preferredDate: date
    preferredTime: str = Field(min_length=1, max_length=30)
    addons: List[str] = Field(default_factory=list)
    isAgent: bool = False
    notes: Optional[str] = Field(default="", max_length=2000)
    website: str = Field(default="", max_length=200)

    _phone_ok = field_validator("phone")(check_phone)
    _date_ok = field_validator("preferredDate")(check_not_past)


class AgentRequestIn(BaseModel):
    agentName: str = Field(min_length=1, max_length=200)
    brokerage: str = Field(min_length=1, max_length=200)
    phone: str = Field(min_length=1, max_length=30)
    email: EmailStr
    clientName: str = Field(min_length=1, max_length=200)
    propertyAddress: str = Field(min_length=1, max_length=300)
    requestedDate: date
    notes: Optional[str] = Field(default="", max_length=2000)
    website: str = Field(default="", max_length=200)

    _phone_ok = field_validator("phone")(check_phone)
    _date_ok = field_validator("requestedDate")(check_not_past)


@api_router.get("/health")
async def health():
    return {"status": "ok"}


@api_router.post("/bookings")
async def create_booking(payload: BookingIn):
    reference = gen_reference()
    if payload.website.strip():
        return {"reference": reference}
    doc = payload.model_dump()
    doc.pop("website", None)
    doc["preferredDate"] = doc["preferredDate"].isoformat()
    doc["reference"] = reference
    doc["createdAt"] = datetime.now(timezone.utc).isoformat()
    await db.bookings.insert_one(doc)
    return {"reference": reference}


@api_router.post("/agent-requests")
async def create_agent_request(payload: AgentRequestIn):
    reference = gen_reference()
    if payload.website.strip():
        return {"reference": reference}
    doc = payload.model_dump()
    doc.pop("website", None)
    doc["requestedDate"] = doc["requestedDate"].isoformat()
    doc["reference"] = reference
    doc["createdAt"] = datetime.now(timezone.utc).isoformat()
    await db.agent_requests.insert_one(doc)
    return {"reference": reference}


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
