import { useEffect } from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import MobileBar from "./components/MobileBar";
import HomePage from "./pages/HomePage";
import SampleReportPage from "./pages/SampleReportPage";
import AgentsPage from "./pages/AgentsPage";

function ScrollManager() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) {
      const t = setTimeout(() => {
        const el = document.getElementById(hash.slice(1));
        if (el) el.scrollIntoView({ behavior: "smooth" });
      }, 80);
      return () => clearTimeout(t);
    }
    window.scrollTo(0, 0);
    return undefined;
  }, [pathname, hash]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter>
      <ScrollManager />
      <a href="#main-content" className="skip-link">
        Skip to content
      </a>
      <Header />
      <div className="pb-14 md:pb-0">
        <main id="main-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/sample-report" element={<SampleReportPage />} />
            <Route path="/agents" element={<AgentsPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
      <MobileBar />
    </BrowserRouter>
  );
}
