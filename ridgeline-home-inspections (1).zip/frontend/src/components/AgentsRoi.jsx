import { Check } from "lucide-react";
import { site } from "../content/site";
import { Reveal, container } from "./ui-bits";

export default function AgentsRoi() {
  const r = site.agentsRoi;
  return (
    <section className="bg-white py-16 md:py-28" data-testid="agents-roi-section">
      <div className={container}>
        <Reveal className="grid items-center gap-10 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <p className="font-heading text-7xl font-bold leading-none text-transparent [-webkit-text-stroke:1.5px_#14283C] md:text-8xl" data-testid="roi-stat">
              {r.stat}
            </p>
            <p className="mt-3 font-heading text-lg font-semibold text-navy">{r.statLabel}</p>
          </div>
          <div className="lg:col-span-8">
            <h2 className="max-w-xl text-[clamp(1.8rem,3.2vw,2.6rem)] font-bold leading-tight text-navy">{r.title}</h2>
            <p className="mt-4 max-w-xl text-slate">{r.text}</p>
            <ul className="mt-6 space-y-2.5" data-testid="roi-points">
              {r.points.map((pt) => (
                <li key={pt} className="flex items-start gap-2.5 text-[15px] text-ink">
                  <Check className="mt-1 h-4 w-4 shrink-0 text-severity-minor" strokeWidth={1.5} aria-hidden="true" />
                  {pt}
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
