import { Link } from "react-router-dom";
import Logo from "./Logo";
import { site } from "../content/site";

export default function Footer() {
  return (
    <footer className="bg-navy text-white" data-testid="site-footer">
      <div className="mx-auto w-full max-w-content px-5 py-14 md:px-8 md:py-16">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <Logo dark />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/70">{site.footerDescription}</p>
            <p className="mt-3 text-xs text-white/50">{site.licenseText}</p>
          </div>
          <div>
            <h2 className="text-sm font-semibold uppercase tracking-[0.14em] text-white/80">Contact</h2>
            <ul className="mt-4 space-y-2.5 text-sm text-white/70">
              <li>
                <a href={`tel:${site.phoneTel}`} data-testid="footer-phone-link" className="hover:text-white">{site.phoneDisplay}</a>
              </li>
              <li>
                <a href={`mailto:${site.email}`} data-testid="footer-email-link" className="hover:text-white">{site.email}</a>
              </li>
              <li>{site.hours}</li>
            </ul>
          </div>
          <div>
            <h2 className="text-sm font-semibold uppercase tracking-[0.14em] text-white/80">Links</h2>
            <ul className="mt-4 space-y-2.5 text-sm text-white/70">
              {site.footerLinks.map((l) => (
                <li key={l.label}>
                  <Link to={l.to} data-testid={`footer-link-${l.label.toLowerCase().replace(/\s+/g, "-")}`} className="hover:text-white">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2 className="text-sm font-semibold uppercase tracking-[0.14em] text-white/80">Service area</h2>
            <ul className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2.5 text-sm text-white/70">
              {site.serviceArea.map((c) => (
                <li key={c}>{c}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      <div className="border-t border-white/15">
        <div className="mx-auto flex w-full max-w-content flex-col gap-2 px-5 py-5 text-xs text-white/60 md:flex-row md:items-center md:justify-between md:px-8">
          <p>© 2026 {site.businessName}. All rights reserved.</p>
          <p data-testid="footer-concept-note">{site.conceptNote}</p>
        </div>
      </div>
    </footer>
  );
}
