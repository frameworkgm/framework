import { useEffect, useRef, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Phone } from "lucide-react";
import Logo from "./Logo";
import { site } from "../content/site";
import { btnPrimary } from "./ui-bits";

const EASE = "cubic-bezier(0.22, 1, 0.36, 1)";

function DemoNoticeBar() {
  const n = site.demoNotice;
  return (
    <div className="bg-navy" data-testid="demo-notice-bar">
      <div className="mx-auto flex w-full max-w-content flex-wrap items-center justify-center gap-x-1.5 gap-y-0.5 px-5 py-2 text-center text-[13px] leading-snug text-white/75 md:px-8">
        <span>{n.text}</span>
        <span className="hidden sm:inline">{n.sub}</span>
        <Link
          to={n.ctaTo}
          data-testid="demo-notice-cta"
          className="font-semibold text-white underline-offset-4 transition-colors duration-200 hover:text-accent hover:underline"
        >
          {n.cta}
        </Link>
      </div>
    </div>
  );
}

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const closeRef = useRef(null);
  const menuBtnRef = useRef(null);
  const drawerRef = useRef(null);
  const wasOpenRef = useRef(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 4);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    window.dispatchEvent(new CustomEvent("drawer-toggle", { detail: open }));
    if (!open) {
      document.documentElement.style.overflow = "";
      document.body.style.overflow = "";
      if (wasOpenRef.current) menuBtnRef.current?.focus();
      wasOpenRef.current = false;
      return undefined;
    }
    wasOpenRef.current = true;
    closeRef.current?.focus();
    document.documentElement.style.overflow = "hidden";
    document.body.style.overflow = "hidden";
    const onKey = (e) => {
      if (e.key === "Escape") setOpen(false);
      if (e.key === "Tab" && drawerRef.current) {
        const els = drawerRef.current.querySelectorAll("a[href], button:not([disabled])");
        if (!els.length) return;
        const first = els[0];
        const last = els[els.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  const isActive = (item) => item.page && location.pathname === item.page;

  return (
    <>
      <DemoNoticeBar />
      <header
        className={`sticky top-0 z-40 h-[72px] border-b transition-colors duration-200 ${
          scrolled ? "border-[#C9C5BC] bg-white/85 backdrop-blur-md" : "border-line bg-white"
        }`}
        data-testid="site-header"
      >
        <div className="mx-auto flex h-full w-full max-w-content items-center justify-between gap-4 px-5 md:px-8">
          <Logo />
          <nav className="hidden items-center gap-6 md:flex" aria-label="Main navigation" data-testid="desktop-nav">
            {site.nav.map((item) => (
              <Link
                key={item.label}
                to={item.to}
                data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                className={`relative py-2 text-[15px] font-medium transition-colors duration-200 ${
                  isActive(item) ? "text-navy" : "text-slate hover:text-navy"
                }`}
              >
                {item.label}
                {isActive(item) && (
                  <span className="absolute inset-x-0 -bottom-[1px] h-[2px] bg-accent" aria-hidden="true" />
                )}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-5">
            <a
              href={`tel:${site.phoneTel}`}
              data-testid="header-phone-link"
              className="hidden items-center gap-2 text-[15px] font-semibold text-navy transition-colors duration-200 hover:text-accent-dark lg:inline-flex"
            >
              <Phone className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
              {site.phoneDisplay}
            </a>
            <Link to="/#book" data-testid="header-book-button" className={`${btnPrimary} hidden md:inline-flex`}>
              Book inspection
            </Link>
            <button
              ref={menuBtnRef}
              type="button"
              data-testid="mobile-menu-button"
              className="flex h-11 w-11 items-center justify-center rounded-md border border-line text-navy md:hidden"
              aria-expanded={open}
              aria-controls="mobile-drawer"
              aria-label="Open menu"
              onClick={() => setOpen(true)}
            >
              <Menu className="h-5 w-5" strokeWidth={1.5} aria-hidden="true" />
            </button>
          </div>
        </div>

        <div
          data-testid="drawer-overlay"
          onClick={() => setOpen(false)}
          aria-hidden="true"
          className="fixed inset-0 z-[60] md:hidden"
          style={{
            background: "rgba(15, 27, 39, 0.45)",
            opacity: open ? 1 : 0,
            visibility: open ? "visible" : "hidden",
            pointerEvents: open ? "auto" : "none",
            transition: open
              ? `opacity 250ms ${EASE}, visibility 0s`
              : `opacity 250ms ${EASE}, visibility 0s linear 250ms`,
            willChange: "opacity",
          }}
        />
        <div
          ref={drawerRef}
          id="mobile-drawer"
          data-testid="mobile-drawer"
          role="dialog"
          aria-modal="true"
          aria-label="Menu"
          aria-hidden={!open}
          inert={!open}
          className="fixed bottom-0 right-0 top-0 z-[70] flex w-[min(88vw,360px)] flex-col bg-white md:hidden"
          style={{
            height: "100dvh",
            transform: open ? "translate3d(0, 0, 0)" : "translate3d(100%, 0, 0)",
            transition: open
              ? `transform 250ms ${EASE}, visibility 0s`
              : `transform 250ms ${EASE}, visibility 0s linear 250ms`,
            visibility: open ? "visible" : "hidden",
            willChange: "transform",
            boxShadow: "0 1px 2px rgba(15, 27, 39, 0.08)",
          }}
        >
          <div className="flex h-[72px] shrink-0 items-center justify-between border-b border-line px-5">
            <Logo />
            <button
              ref={closeRef}
              type="button"
              data-testid="mobile-menu-close"
              className="flex h-11 w-11 items-center justify-center rounded-md border border-line text-navy"
              aria-label="Close menu"
              onClick={() => setOpen(false)}
            >
              <X className="h-5 w-5" strokeWidth={1.5} aria-hidden="true" />
            </button>
          </div>
          <nav className="flex flex-1 flex-col gap-1 overflow-y-auto px-5 py-6" aria-label="Mobile navigation">
            {site.nav.map((item) => (
              <Link
                key={item.label}
                to={item.to}
                data-testid={`drawer-nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                onClick={() => setOpen(false)}
                className={`border-b border-line py-4 font-heading text-lg font-semibold ${isActive(item) ? "text-accent-dark" : "text-navy"}`}
              >
                {item.label}
              </Link>
            ))}
            <a
              href={`tel:${site.phoneTel}`}
              data-testid="drawer-phone-link"
              className="mt-6 inline-flex items-center gap-2 text-base font-semibold text-navy"
            >
              <Phone className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
              {site.phoneDisplay}
            </a>
            <Link to="/#book" data-testid="drawer-book-button" onClick={() => setOpen(false)} className={`${btnPrimary} mt-4 w-full`}>
              Book inspection
            </Link>
          </nav>
        </div>
      </header>
    </>
  );
}
