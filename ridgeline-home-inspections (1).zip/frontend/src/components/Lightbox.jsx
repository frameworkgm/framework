import { useEffect, useRef } from "react";
import { X } from "lucide-react";

export default function Lightbox({ src, alt, caption, onClose, triggerRef }) {
  const closeRef = useRef(null);

  useEffect(() => {
    closeRef.current?.focus();
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "Tab") {
        e.preventDefault();
        closeRef.current?.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
      if (triggerRef?.current) triggerRef.current.focus();
    };
  }, [onClose, triggerRef]);

  return (
    <div
      className="fade-in fixed inset-0 z-[60] flex items-center justify-center bg-ink/85 p-4"
      role="dialog"
      aria-modal="true"
      aria-label={caption}
      data-testid="lightbox"
      onClick={onClose}
    >
      <figure className="max-w-4xl" onClick={(e) => e.stopPropagation()}>
        <img src={src} alt={alt} className="max-h-[78vh] w-auto rounded-lg" />
        <figcaption className="mt-3 flex items-start justify-between gap-4">
          <span className="text-sm text-white/85">{caption}</span>
          <button
            ref={closeRef}
            type="button"
            data-testid="lightbox-close"
            aria-label="Close image viewer"
            onClick={onClose}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md border border-white/30 text-white hover:bg-white/10"
          >
            <X className="h-5 w-5" strokeWidth={1.5} aria-hidden="true" />
          </button>
        </figcaption>
      </figure>
    </div>
  );
}
