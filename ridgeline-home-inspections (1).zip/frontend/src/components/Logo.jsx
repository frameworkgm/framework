import { Link } from "react-router-dom";
import { site } from "../content/site";

export function RoofMark({ className = "h-6 w-6" }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M4 13 L12 5 L20 13" />
      <path d="M12 10.5 L12 18" />
    </svg>
  );
}

export default function Logo({ dark = false }) {
  return (
    <Link to="/" className="flex items-center gap-2.5" data-testid="logo-link" aria-label={`${site.businessName} home`}>
      <span
        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-md ${
          dark ? "bg-white/10 text-accent" : "bg-navy text-accent"
        }`}
      >
        <RoofMark className="h-6 w-6" />
      </span>
      <span className="leading-none">
        <span className={`block font-heading text-xl font-bold ${dark ? "text-white" : "text-navy"}`}>
          {site.shortName}
        </span>
        <span className={`mt-1 block text-[10px] font-semibold uppercase tracking-[0.22em] ${dark ? "text-white/60" : "text-slate"}`}>
          Home Inspections
        </span>
      </span>
    </Link>
  );
}
