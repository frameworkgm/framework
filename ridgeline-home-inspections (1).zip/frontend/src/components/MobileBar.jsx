import { Link } from "react-router-dom";
import { Phone, CalendarCheck } from "lucide-react";
import { site } from "../content/site";

export default function MobileBar() {
  return (
    <div
      className="fixed inset-x-0 bottom-0 z-30 grid h-14 grid-cols-2 bg-navy md:hidden"
      data-testid="mobile-action-bar"
    >
      <a
        href={`tel:${site.phoneTel}`}
        data-testid="mobile-bar-call"
        className="flex items-center justify-center gap-2 text-sm font-semibold text-white"
      >
        <Phone className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
        Call
      </a>
      <Link
        to="/#book"
        data-testid="mobile-bar-book"
        className="flex items-center justify-center gap-2 border-l border-white/15 text-sm font-semibold text-white"
      >
        <CalendarCheck className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
        Book
      </Link>
    </div>
  );
}
