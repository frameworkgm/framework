import { site } from "../content/site";

export const inputCls =
  "min-h-[48px] w-full rounded-md border border-line bg-white px-3.5 py-2.5 text-base text-ink placeholder:text-slate/60 transition-colors duration-150 focus:border-navy";

export function Field({ label, id, error, required = false, children, className = "" }) {
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1.5 block text-sm font-semibold text-ink">
        {label}
        {required && (
          <span className="text-severity-major" aria-hidden="true">
            {" "}*
          </span>
        )}
      </label>
      {children}
      {error && (
        <p id={`${id}-error`} role="alert" className="mt-1.5 text-sm text-severity-safety">
          {error}
        </p>
      )}
    </div>
  );
}

export function AddonCheckboxes({ selected, onToggle, idPrefix }) {
  return (
    <div className="space-y-2">
      {site.pricing.addons.map((a) => (
        <label
          key={a.id}
          htmlFor={`${idPrefix}-addon-${a.id}`}
          className="flex cursor-pointer items-center justify-between gap-3 rounded-md border border-line bg-white px-3.5 py-2.5 transition-colors duration-150 hover:border-slate"
        >
          <span className="flex items-center gap-2.5 text-[15px]">
            <input
              type="checkbox"
              id={`${idPrefix}-addon-${a.id}`}
              data-testid={`${idPrefix}-addon-${a.id}`}
              className="h-4 w-4 shrink-0 accent-[#E8731A]"
              checked={selected.includes(a.id)}
              onChange={() => onToggle(a.id)}
            />
            {a.name}
          </span>
          <span className="text-sm text-slate">${a.price}</span>
        </label>
      ))}
    </div>
  );
}

export function Honeypot({ value, onChange }) {
  return (
    <div className="absolute -left-[9999px] top-0 h-0 w-0 overflow-hidden" aria-hidden="true">
      <label htmlFor="hp-website">Website</label>
      <input
        type="text"
        id="hp-website"
        name="website"
        tabIndex={-1}
        autoComplete="off"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
}

export const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
export const isPhone = (v) => v.replace(/\D/g, "").length >= 10;
