import { Link } from "react-router-dom";
import { site } from "../../content/site";
import { Reveal, btnSecondaryDark, container } from "../ui-bits";

export default function AgentsBand() {
  const b = site.agentsBand;
  return (
    <section className="bg-navy-soft py-14 md:py-16" data-testid="agents-band-section">
      <div className={container}>
        <Reveal className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="font-heading text-2xl font-bold text-white md:text-3xl">{b.title}</h2>
            <p className="mt-2 text-white/80">{b.text}</p>
          </div>
          <Link to="/agents" data-testid="agents-band-button" className={`${btnSecondaryDark} shrink-0`}>
            {b.cta}
          </Link>
        </Reveal>
      </div>
    </section>
  );
}
