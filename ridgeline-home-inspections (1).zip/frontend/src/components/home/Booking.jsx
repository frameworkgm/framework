import { useEffect, useState } from "react";
import axios from "axios";
import { Phone } from "lucide-react";
import { site } from "../../content/site";
import { Reveal, container, btnPrimary } from "../ui-bits";
import { Field, Honeypot, AddonCheckboxes, inputCls, isEmail, isPhone } from "../forms";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;
const empty = {
  fullName: "", phone: "", email: "", propertyAddress: "", cityZip: "",
  propertyType: "Single-family", squareFootage: "", yearBuilt: "",
  preferredDate: "", preferredTime: "Morning", addons: [], isAgent: false,
  notes: "", website: "",
};

export default function Booking() {
  const b = site.booking;
  const [form, setForm] = useState(empty);
  const [errors, setErrors] = useState({});
  const [sending, setSending] = useState(false);
  const [reference, setReference] = useState("");
  const [submitError, setSubmitError] = useState("");
  const today = new Date().toISOString().split("T")[0];

  useEffect(() => {
    const apply = (d) => {
      if (!d) return;
      setForm((f) => ({
        ...f,
        squareFootage: d.sqft ? String(d.sqft) : f.squareFootage,
        yearBuilt: d.year ? String(d.year) : f.yearBuilt,
        addons: Array.isArray(d.addons) ? d.addons : f.addons,
      }));
    };
    try {
      apply(JSON.parse(sessionStorage.getItem("ridgeline-prefill")));
      sessionStorage.removeItem("ridgeline-prefill");
    } catch { /* no prefill */ }
    const onPrefill = (e) => apply(e.detail);
    window.addEventListener("booking-prefill", onPrefill);
    return () => window.removeEventListener("booking-prefill", onPrefill);
  }, []);

  const set = (k) => (e) => {
    const v = e.target.type === "checkbox" ? e.target.checked : e.target.value;
    setForm((f) => ({ ...f, [k]: v }));
    setErrors((er) => ({ ...er, [k]: "" }));
  };

  const toggleAddon = (id) =>
    setForm((f) => ({ ...f, addons: f.addons.includes(id) ? f.addons.filter((x) => x !== id) : [...f.addons, id] }));

  const validate = () => {
    const er = {};
    if (!form.fullName.trim()) er.fullName = "Please enter your full name.";
    if (!isPhone(form.phone)) er.phone = "Please enter a phone number we can reach you on.";
    if (!isEmail(form.email)) er.email = "Please enter a valid email address.";
    if (!form.propertyAddress.trim()) er.propertyAddress = "Please enter the property address.";
    if (!form.cityZip.trim()) er.cityZip = "Please enter the city and ZIP code.";
    if (!form.preferredDate) er.preferredDate = "Please pick a preferred date.";
    else if (form.preferredDate < today) er.preferredDate = "Please pick a date that is not in the past.";
    return er;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    setSubmitError("");
    const er = validate();
    setErrors(er);
    if (Object.keys(er).length) return;
    setSending(true);
    try {
      const res = await axios.post(`${API}/bookings`, {
        fullName: form.fullName.trim(),
        phone: form.phone.trim(),
        email: form.email.trim(),
        propertyAddress: form.propertyAddress.trim(),
        cityZip: form.cityZip.trim(),
        propertyType: form.propertyType,
        squareFootage: form.squareFootage ? Number(form.squareFootage) : null,
        yearBuilt: form.yearBuilt ? Number(form.yearBuilt) : null,
        preferredDate: form.preferredDate,
        preferredTime: form.preferredTime,
        addons: form.addons,
        isAgent: form.isAgent,
        notes: form.notes.trim(),
        website: form.website,
      });
      setReference(res.data.reference);
    } catch {
      setSubmitError(`Something went wrong on our end. Your details are still here. Please try again, or call us at ${site.phoneDisplay}.`);
    } finally {
      setSending(false);
    }
  };

  return (
    <section id="book" className="relative scroll-mt-24" data-testid="booking-section">
      <div className="absolute inset-x-0 top-0 h-[72%] bg-navy" aria-hidden="true" />
      <div className="absolute inset-x-0 bottom-0 h-[28%] bg-paper" aria-hidden="true" />
      <div className={`relative ${container} grid gap-10 py-16 md:py-28 lg:grid-cols-12`}>
        <Reveal className="lg:col-span-5">
          <h2 className="text-[clamp(1.8rem,3.2vw,2.6rem)] font-bold leading-tight text-white">{b.title}</h2>
          <p className="mt-4 max-w-md text-white/80">{b.text}</p>
          <a
            href={`tel:${site.phoneTel}`}
            data-testid="booking-phone-link"
            className="mt-8 inline-flex items-center gap-3 font-heading text-2xl font-bold text-white hover:text-accent"
          >
            <Phone className="h-6 w-6" strokeWidth={1.5} aria-hidden="true" />
            {site.phoneDisplay}
          </a>
          <p className="mt-2 text-sm text-white/60">{site.hours}</p>
        </Reveal>

        <Reveal className="lg:col-span-7">
          <div className="rounded-lg border border-line bg-white p-6 md:p-8" aria-live="polite">
            {reference ? (
              <div data-testid="booking-success" className="fade-in flex min-h-[380px] flex-col justify-center">
                <h3 className="font-heading text-2xl font-bold text-navy">{b.successTitle}</h3>
                <p className="mt-3 text-ink">
                  Your reference: <strong className="font-semibold" data-testid="booking-reference">{reference}</strong>
                </p>
                <p className="mt-2 text-slate">{b.successNote}</p>
              </div>
            ) : (
              <form onSubmit={onSubmit} noValidate data-testid="booking-form" className="relative">
                <div className="grid gap-5 sm:grid-cols-2">
                  <Field label="Full name" id="bk-name" required error={errors.fullName}>
                    <input id="bk-name" data-testid="booking-name-input" className={inputCls} value={form.fullName} onChange={set("fullName")} autoComplete="name" aria-invalid={!!errors.fullName} aria-describedby={errors.fullName ? "bk-name-error" : undefined} />
                  </Field>
                  <Field label="Phone" id="bk-phone" required error={errors.phone}>
                    <input id="bk-phone" data-testid="booking-phone-input" type="tel" className={inputCls} value={form.phone} onChange={set("phone")} autoComplete="tel" aria-invalid={!!errors.phone} aria-describedby={errors.phone ? "bk-phone-error" : undefined} />
                  </Field>
                  <Field label="Email" id="bk-email" required error={errors.email} className="sm:col-span-2">
                    <input id="bk-email" data-testid="booking-email-input" type="email" className={inputCls} value={form.email} onChange={set("email")} autoComplete="email" aria-invalid={!!errors.email} aria-describedby={errors.email ? "bk-email-error" : undefined} />
                  </Field>
                  <Field label="Property address" id="bk-address" required error={errors.propertyAddress} className="sm:col-span-2">
                    <input id="bk-address" data-testid="booking-address-input" className={inputCls} value={form.propertyAddress} onChange={set("propertyAddress")} autoComplete="street-address" aria-invalid={!!errors.propertyAddress} aria-describedby={errors.propertyAddress ? "bk-address-error" : undefined} />
                  </Field>
                  <Field label="City and ZIP" id="bk-cityzip" required error={errors.cityZip}>
                    <input id="bk-cityzip" data-testid="booking-cityzip-input" className={inputCls} placeholder={b.cityZipPlaceholder} value={form.cityZip} onChange={set("cityZip")} aria-invalid={!!errors.cityZip} aria-describedby={errors.cityZip ? "bk-cityzip-error" : undefined} />
                  </Field>
                  <Field label="Property type" id="bk-type">
                    <select id="bk-type" data-testid="booking-type-select" className={inputCls} value={form.propertyType} onChange={set("propertyType")}>
                      {b.propertyTypes.map((t) => (
                        <option key={t} value={t}>{t}</option>
                      ))}
                    </select>
                  </Field>
                  <Field label="Approximate square footage" id="bk-sqft">
                    <input id="bk-sqft" data-testid="booking-sqft-input" type="text" inputMode="numeric" pattern="[0-9]*" autoComplete="off" className={inputCls} value={form.squareFootage} onChange={(e) => setForm((f) => ({ ...f, squareFootage: e.target.value.replace(/\D/g, "").slice(0, 5).replace(/^0+/, "") }))} />
                  </Field>
                  <Field label="Year built" id="bk-year">
                    <input id="bk-year" data-testid="booking-year-input" type="text" inputMode="numeric" pattern="[0-9]*" autoComplete="off" className={inputCls} value={form.yearBuilt} onChange={(e) => setForm((f) => ({ ...f, yearBuilt: e.target.value.replace(/\D/g, "").slice(0, 4).replace(/^0+/, "") }))} />
                  </Field>
                  <Field label="Preferred date" id="bk-date" required error={errors.preferredDate}>
                    <input id="bk-date" data-testid="booking-date-input" type="date" min={today} className={inputCls} value={form.preferredDate} onChange={set("preferredDate")} aria-invalid={!!errors.preferredDate} aria-describedby={errors.preferredDate ? "bk-date-error" : undefined} />
                  </Field>
                  <fieldset>
                    <legend className="mb-1.5 text-sm font-semibold text-ink">Preferred time</legend>
                    <div className="flex min-h-[48px] flex-wrap items-center gap-x-5 gap-y-2">
                      {b.timeOptions.map((t) => (
                        <label key={t} className="flex items-center gap-2 text-[15px]" htmlFor={`bk-time-${t.toLowerCase()}`}>
                          <input
                            type="radio"
                            id={`bk-time-${t.toLowerCase()}`}
                            data-testid={`booking-time-${t.toLowerCase()}`}
                            name="preferredTime"
                            value={t}
                            checked={form.preferredTime === t}
                            onChange={set("preferredTime")}
                            className="h-4 w-4 accent-[#E8731A]"
                          />
                          {t}
                        </label>
                      ))}
                    </div>
                  </fieldset>
                  <fieldset className="sm:col-span-2">
                    <legend className="mb-2 text-sm font-semibold text-ink">Add-on tests</legend>
                    <AddonCheckboxes selected={form.addons} onToggle={toggleAddon} idPrefix="bk" />
                  </fieldset>
                  <label htmlFor="bk-is-agent" className="flex items-center gap-2.5 text-[15px] sm:col-span-2">
                    <input
                      type="checkbox"
                      id="bk-is-agent"
                      data-testid="booking-agent-checkbox"
                      className="h-4 w-4 accent-[#E8731A]"
                      checked={form.isAgent}
                      onChange={set("isAgent")}
                    />
                    {b.agentCheckbox}
                  </label>
                  <Field label="Notes (optional)" id="bk-notes" className="sm:col-span-2">
                    <textarea id="bk-notes" data-testid="booking-notes-input" rows={3} className={`${inputCls} min-h-0`} value={form.notes} onChange={set("notes")} />
                  </Field>
                </div>
                <Honeypot value={form.website} onChange={(v) => setForm((f) => ({ ...f, website: v }))} />
                {submitError && (
                  <p role="alert" data-testid="booking-error" className="mt-4 rounded-md border border-severity-safety/30 bg-severity-safety/5 px-4 py-3 text-sm text-severity-safety">
                    {submitError}
                  </p>
                )}
                <button type="submit" data-testid="booking-submit-button" disabled={sending} className={`${btnPrimary} mt-6 w-full disabled:cursor-not-allowed disabled:opacity-60`}>
                  {sending ? "Sending..." : b.submitLabel}
                </button>
              </form>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
