import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { site } from "../../content/site";
import { Eyebrow, Reveal, container } from "../ui-bits";

export default function Different() {
  const d = site.different;
  return (
    <section id="different" className="scroll-mt-24 bg-paper py-16 md:py-28" data-testid="different-section">
      <div className={container}>
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <Reveal className="lg:sticky lg:top-28">
              <Eyebrow>{d.eyebrow}</Eyebrow>
              <h2 className="text-[clamp(1.8rem,3.2vw,2.6rem)] font-bold leading-tight text-navy">{d.title}</h2>
              <p className="mt-4 text-slate">{d.text}</p>
              <Link
                to="/sample-report"
                data-testid="different-report-link"
                className="mt-5 inline-flex items-center gap-1.5 font-semibold text-navy underline-offset-4 transition-colors duration-200 hover:text-accent-dark hover:underline"
              >
                {d.linkText}
                <ArrowRight className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
              </Link>
            </Reveal>
          </div>
          <div className="lg:col-span-8">
            <Reveal>
              {d.rows.map((r, i) => (
                <div key={r.title} className={`grid gap-2 py-7 sm:grid-cols-[220px_1fr] sm:gap-8 ${i === 0 ? "border-t border-line" : ""} border-b border-line`} data-testid={`different-row-${i}`}>
                  <h3 className="font-heading text-xl font-semibold leading-snug text-ink">{r.title}</h3>
                  <div>
                    <p className="text-[16.5px] leading-relaxed text-slate">{r.body}</p>
                    <p className="mt-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-accent-dark">{r.caption}</p>
                  </div>
                </div>
              ))}
              <p className="mt-7 text-slate" data-testid="different-closing">
                {d.closingPre}{" "}
                <Link to="/sample-report" className="font-semibold text-navy underline-offset-4 transition-colors duration-200 hover:text-accent-dark hover:underline">
                  {d.closingLink}
                </Link>
                {d.closingMid}{" "}
                <a href={`tel:${site.phoneTel}`} className="font-semibold text-navy underline-offset-4 transition-colors duration-200 hover:text-accent-dark hover:underline" data-testid="different-phone-link">
                  {site.phoneDisplay}
                </a>
                .
              </p>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
