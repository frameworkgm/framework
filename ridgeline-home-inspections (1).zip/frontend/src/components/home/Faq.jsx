import { useLayoutEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Plus, Minus, Search } from "lucide-react";
import { site } from "../../content/site";
import { Reveal, btnPrimary, btnSecondaryDark, container } from "../ui-bits";

const ALL = "All questions";

function AccordionRow({ item, open, onToggle, uid }) {
  const panelRef = useRef(null);
  const [height, setHeight] = useState(0);

  useLayoutEffect(() => {
    if (open && panelRef.current) setHeight(panelRef.current.scrollHeight);
  }, [open]);

  return (
    <div
      className={`border-b border-line transition-colors duration-200 ${
        open ? "border-l-[3px] border-l-accent bg-paper/60 pl-4" : "border-l-[3px] border-l-transparent pl-4 hover:bg-paper/60"
      }`}
    >
      <h3>
        <button
          type="button"
          data-testid={`faq-question-${uid}`}
          aria-expanded={open}
          aria-controls={`faq-panel-${uid}`}
          id={`faq-button-${uid}`}
          onClick={onToggle}
          className="flex w-full items-center justify-between gap-4 py-5 pr-1 text-left font-heading text-lg font-semibold text-ink transition-colors duration-200 hover:text-navy"
        >
          {item.q}
          {open ? (
            <Minus className="h-5 w-5 shrink-0 text-accent-dark" strokeWidth={1.5} aria-hidden="true" />
          ) : (
            <Plus className="h-5 w-5 shrink-0 text-slate" strokeWidth={1.5} aria-hidden="true" />
          )}
        </button>
      </h3>
      <div
        id={`faq-panel-${uid}`}
        role="region"
        aria-labelledby={`faq-button-${uid}`}
        style={{
          maxHeight: open ? height : 0,
          overflow: "hidden",
          transition: "max-height 250ms cubic-bezier(0.22, 1, 0.36, 1)",
        }}
      >
        <div ref={panelRef}>
          <p className="max-w-[68ch] pb-6 text-[16.5px] leading-[1.7] text-slate" data-testid={`faq-answer-${uid}`}>
            {item.a}
          </p>
        </div>
      </div>
    </div>
  );
}

export default function Faq() {
  const f = site.faqSection;
  const [cat, setCat] = useState(ALL);
  const [query, setQuery] = useState("");
  const [openUid, setOpenUid] = useState(null);

  const counts = useMemo(() => {
    const c = { [ALL]: f.items.length };
    f.categories.forEach((k) => {
      c[k] = f.items.filter((i) => i.c === k).length;
    });
    return c;
  }, [f]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return f.items.filter((i) => {
      const inCat = cat === ALL || i.c === cat;
      const inQuery = !q || i.q.toLowerCase().includes(q) || i.a.toLowerCase().includes(q);
      return inCat && inQuery;
    });
  }, [f, cat, query]);

  const grouped = cat === ALL && !query.trim();

  const uid = (item) => f.items.indexOf(item);

  const faqJsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: f.items.map((i) => ({
      "@type": "Question",
      name: i.q,
      acceptedAnswer: { "@type": "Answer", text: i.a },
    })),
  };

  const renderRow = (item) => (
    <AccordionRow
      key={item.q}
      item={item}
      uid={uid(item)}
      open={openUid === uid(item)}
      onToggle={() => setOpenUid(openUid === uid(item) ? null : uid(item))}
    />
  );

  return (
    <section id="faq" className="scroll-mt-24 bg-white py-16 md:py-28" data-testid="faq-section">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }} />
      <div className={container}>
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <h2 className="text-[clamp(1.8rem,3.2vw,2.6rem)] font-bold text-navy">{f.title}</h2>
              <p className="mt-2 text-slate">
                {f.subPrefix}{" "}
                <a href={`tel:${site.phoneTel}`} className="font-semibold text-navy underline-offset-4 transition-colors duration-200 hover:text-accent-dark hover:underline" data-testid="faq-phone-link">
                  {site.phoneDisplay}
                </a>
                .
              </p>
            </div>
            <div className="relative w-full sm:w-72">
              <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate" strokeWidth={1.5} aria-hidden="true" />
              <input
                type="search"
                data-testid="faq-search-input"
                aria-label="Search questions"
                placeholder={f.searchPlaceholder}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="min-h-[48px] w-full rounded-md border border-line bg-white pl-10 pr-3.5 text-base text-ink transition-colors duration-200 focus:border-navy"
              />
            </div>
          </div>
        </Reveal>

        <p className="sr-only" aria-live="polite" data-testid="faq-result-count">
          {visible.length} questions shown
        </p>

        <div className="mt-10 grid gap-10 lg:grid-cols-12">
          <Reveal className="min-w-0 lg:col-span-3">
            <div className="lg:sticky lg:top-28">
              <div className="-mx-5 flex gap-5 overflow-x-auto px-5 lg:mx-0 lg:flex-col lg:gap-0 lg:overflow-visible lg:px-0" role="tablist" aria-label="Question categories" data-testid="faq-categories">
                {[ALL, ...f.categories].map((c) => {
                  const active = cat === c;
                  return (
                    <button
                      key={c}
                      type="button"
                      role="tab"
                      aria-selected={active}
                      data-testid={`faq-cat-${c.toLowerCase().replace(/\s+/g, "-")}`}
                      onClick={() => {
                        setCat(c);
                        setOpenUid(null);
                      }}
                      className={`whitespace-nowrap py-2.5 text-left text-[15px] transition-colors duration-200 lg:py-3 ${
                        active
                          ? "border-b-2 border-accent font-bold text-navy lg:border-b-0 lg:border-l-[3px] lg:pl-3"
                          : "border-b-2 border-transparent text-slate hover:text-navy lg:border-l-[3px] lg:pl-3"
                      }`}
                    >
                      {c} <span className="text-slate">({counts[c]})</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </Reveal>

          <Reveal className="min-w-0 lg:col-span-9">
            {visible.length === 0 ? (
              <p className="border-t border-line py-8 text-slate" data-testid="faq-no-match">
                {f.noMatchPrefix}{" "}
                <a href={`tel:${site.phoneTel}`} className="font-semibold text-navy underline-offset-4 hover:underline">
                  {site.phoneDisplay}
                </a>{" "}
                {f.noMatchSuffix}
              </p>
            ) : grouped ? (
              f.categories.map((c) => {
                const rows = visible.filter((i) => i.c === c);
                if (!rows.length) return null;
                return (
                  <div key={c} className="mb-8">
                    <p className="mb-1 text-xs font-semibold uppercase tracking-[0.14em] text-slate" data-testid={`faq-group-${c.toLowerCase().replace(/\s+/g, "-")}`}>
                      {c}
                    </p>
                    {rows.map(renderRow)}
                  </div>
                );
              })
            ) : (
              <div>{visible.map(renderRow)}</div>
            )}

            <div className="mt-10 flex flex-col gap-5 rounded-lg bg-navy p-6 sm:flex-row sm:items-center sm:justify-between md:p-8" data-testid="faq-cta-block">
              <p className="font-heading text-xl font-semibold text-white">{f.ctaTitle}</p>
              <div className="flex flex-col gap-3 sm:flex-row">
                <Link to="/#book" data-testid="faq-cta-book" className={btnPrimary}>
                  {f.ctaPrimary}
                </Link>
                <a href={`tel:${site.phoneTel}`} data-testid="faq-cta-call" className={btnSecondaryDark}>
                  {f.ctaCallPrefix} {site.phoneDisplay}
                </a>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
