import { memo, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Check } from "lucide-react";
import { site } from "../../content/site";
import { btnPrimary, btnSecondaryDark, container } from "../ui-bits";

// Video slot waits for /public/videos/hero.mp4 + hero.webm; poster shows until a file exists.
const POSTER = "/images/hero-exterior.webp";

function Hero() {
  const h = site.hero;
  const videoRef = useRef(null);
  const sectionRef = useRef(null);
  const wasPlayingRef = useRef(false);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const [allow] = useState(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const saveData = typeof navigator !== "undefined" && navigator.connection && navigator.connection.saveData;
    return !reduced && !saveData;
  });

  useEffect(() => {
    if (!allow || failed) return undefined;
    const v = videoRef.current;
    const sec = sectionRef.current;
    if (!v || !sec) return undefined;
    let inView = true;
    const sync = () => {
      if (document.hidden || !inView) {
        v.pause();
      } else {
        v.play().catch(() => {});
      }
    };
    const io = new IntersectionObserver(
      ([entry]) => {
        inView = entry.isIntersecting;
        sync();
      },
      { threshold: 0.05 }
    );
    io.observe(sec);
    document.addEventListener("visibilitychange", sync);
    return () => {
      io.disconnect();
      document.removeEventListener("visibilitychange", sync);
    };
  }, [allow, failed]);

  useEffect(() => {
    const onDrawerToggle = (e) => {
      const v = videoRef.current;
      if (!v) return;
      if (e.detail) {
        wasPlayingRef.current = !v.paused;
        v.pause();
      } else if (wasPlayingRef.current) {
        v.play().catch(() => {});
        wasPlayingRef.current = false;
      }
    };
    window.addEventListener("drawer-toggle", onDrawerToggle);
    return () => window.removeEventListener("drawer-toggle", onDrawerToggle);
  }, []);

  const showVideo = allow && !failed;

  return (
    <section
      ref={sectionRef}
      className="relative h-[calc(100vh-72px)] min-h-[620px] max-h-[860px] overflow-hidden bg-navy"
      data-testid="hero-section"
    >
      <img
        src={POSTER}
        alt=""
        aria-hidden="true"
        width={1920}
        height={1080}
        fetchPriority="high"
        data-testid="hero-poster"
        className="absolute inset-0 h-full w-full object-cover object-center"
      />
      {showVideo && (
        <video
          ref={videoRef}
          data-testid="hero-video"
          className={`absolute inset-0 h-full w-full object-cover object-center transition-opacity duration-[400ms] ${
            ready ? "opacity-100" : "opacity-0"
          }`}
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
          disablePictureInPicture
          controlsList="nodownload"
          poster={POSTER}
          aria-hidden="true"
          tabIndex={-1}
          onPlaying={() => setReady(true)}
          onError={() => setFailed(true)}
        >
          <source src="/videos/hero.webm" type="video/webm" onError={() => setFailed(true)} />
          <source src="/videos/hero.mp4" type="video/mp4" onError={() => setFailed(true)} />
        </video>
      )}
      <div className="absolute inset-0" style={{ background: "rgba(20, 40, 60, 0.35)" }} aria-hidden="true" />
      <div
        className="absolute inset-0 hidden md:block"
        style={{ background: "linear-gradient(to right, rgba(20, 40, 60, 0.85) 0%, rgba(20, 40, 60, 0.25) 70%)" }}
        aria-hidden="true"
      />
      <div
        className="absolute inset-0 md:hidden"
        style={{ background: "linear-gradient(to bottom, rgba(20, 40, 60, 0.80) 0%, rgba(20, 40, 60, 0.55) 100%)" }}
        aria-hidden="true"
      />
      <div className={`relative z-10 ${container} flex h-full items-center`}>
        <div className="max-w-[640px]">
          <p className="mb-3 flex items-center gap-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-white/80">
            <span className="inline-block h-[2px] w-6 bg-accent" aria-hidden="true" />
            {h.eyebrow}
          </p>
          <h1 className="text-[clamp(2.4rem,5vw,4rem)] font-bold leading-[1.08] text-white">{h.title}</h1>
          <p className="mt-5 text-base text-white/85 md:text-lg">{h.subtext}</p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link to="/#book" data-testid="hero-book-button" className={btnPrimary}>
              {h.primaryCta}
            </Link>
            <Link to="/sample-report" data-testid="hero-sample-button" className={btnSecondaryDark}>
              {h.secondaryCta}
            </Link>
          </div>
          <p className="mt-6 flex items-center gap-2 text-sm text-white/75">
            <Check className="h-4 w-4 text-severity-minor" strokeWidth={1.5} aria-hidden="true" />
            {h.note}
          </p>
        </div>
      </div>
    </section>
  );
}

export default memo(Hero);
