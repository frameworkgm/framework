import { site } from "../../content/site";
import { Reveal, container } from "../ui-bits";

export default function HowItWorks() {
  return (
    <section className="bg-white py-16 md:py-28" data-testid="how-it-works-section">
      <div className={container}>
        <Reveal>
          <h2 className="text-[clamp(1.8rem,3.2vw,2.6rem)] font-bold text-navy">How it works</h2>
        </Reveal>
        <div className="relative mt-12">
          <div className="absolute left-0 right-0 top-7 hidden h-px bg-line md:block" aria-hidden="true" />
          <ol className="grid gap-10 md:grid-cols-3">
            {site.steps.map((s, i) => (
              <Reveal as="li" key={s.title} className="relative">
                <span
                  className="relative z-10 inline-block bg-white pr-5 font-heading text-6xl font-bold leading-none text-transparent [-webkit-text-stroke:1.5px_#14283C]"
                  aria-hidden="true"
                >
                  {i + 1}
                </span>
                <h3 className="mt-4 font-heading text-xl font-semibold text-ink">{s.title}</h3>
                <p className="mt-2 max-w-xs text-[15px] leading-relaxed text-slate">{s.text}</p>
              </Reveal>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
