import { Check } from "lucide-react";
import { site } from "../../content/site";
import { Eyebrow, Reveal, container } from "../ui-bits";

export default function Inspector() {
  const p = site.inspector;
  const facts = [p.years, p.homes, site.licenseText];
  return (
    <section className="bg-white py-16 md:py-28" data-testid="inspector-section">
      <div className={container}>
        <div className="grid items-center gap-12 lg:grid-cols-12">
          <Reveal className="lg:col-span-5">
            <img
              src={p.photo}
              alt={p.alt}
              width={1400}
              height={1050}
              loading="lazy"
              data-testid="inspector-photo"
              className="aspect-[4/3] w-full rounded-lg border border-line object-cover"
            />
          </Reveal>
          <Reveal className="lg:col-span-7">
            <Eyebrow>{p.eyebrow}</Eyebrow>
            <h2 className="text-[clamp(1.8rem,3.2vw,2.6rem)] font-bold leading-tight text-navy">{p.title}</h2>
            <p className="mt-5 font-heading text-lg font-semibold text-ink">
              {p.name}, {p.role}
            </p>
            <p className="mt-3 max-w-2xl text-slate">{p.story}</p>
            <ul className="mt-7 max-w-md" data-testid="inspector-facts">
              {facts.map((f) => (
                <li key={f} className="flex items-center gap-3 border-t border-line py-3.5 text-[15px] text-ink">
                  <Check className="h-4 w-4 shrink-0 text-severity-minor" strokeWidth={1.5} aria-hidden="true" />
                  {f}
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
