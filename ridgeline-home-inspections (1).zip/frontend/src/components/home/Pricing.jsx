import { useMemo, useRef, useState } from "react";
import { site, computeEstimate } from "../../content/site";
import { Reveal, container, btnPrimary } from "../ui-bits";
import { AddonCheckboxes, inputCls } from "../forms";

const currentYear = new Date().getFullYear();
const SQFT_MIN = site.pricing.sqftMin;
const SQFT_MAX = site.pricing.sqftMax;
const YEAR_MIN = site.pricing.yearMin;

const sanitize = (raw, maxLen) => raw.replace(/\D/g, "").slice(0, maxLen).replace(/^0+/, "");
const parseNum = (t) => (/^\d+$/.test(t) ? parseInt(t, 10) : null);
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));

export default function Pricing() {
  const p = site.pricing;
  const [sqftText, setSqftText] = useState("2150");
  const [yearText, setYearText] = useState("1994");
  const [lastSqft, setLastSqft] = useState(2150);
  const [lastYear, setLastYear] = useState(1994);
  const [sqftMsg, setSqftMsg] = useState("");
  const [yearMsg, setYearMsg] = useState("");
  const [addons, setAddons] = useState([]);
  const sqftRef = useRef(null);
  const yearRef = useRef(null);

  const sqftNum = parseNum(sqftText);
  const yearNum = parseNum(yearText);
  const sqftValid = sqftNum !== null && sqftNum >= SQFT_MIN && sqftNum <= SQFT_MAX;
  const yearValid = yearNum !== null && yearNum >= YEAR_MIN && yearNum <= currentYear;
  const ready = sqftValid && yearValid;

  const estimate = useMemo(
    () => (ready ? computeEstimate(sqftNum, yearNum, addons) : null),
    [ready, sqftNum, yearNum, addons]
  );

  const sliderValue = clamp(sqftNum !== null ? sqftNum : lastSqft, SQFT_MIN, SQFT_MAX);

  const commitSqft = () => {
    const n = parseNum(sqftText);
    if (n === null) {
      setSqftText(String(lastSqft));
      setSqftMsg("");
      return;
    }
    if (n < SQFT_MIN) {
      setSqftText(String(SQFT_MIN));
      setLastSqft(SQFT_MIN);
      setSqftMsg(`We set this to ${SQFT_MIN.toLocaleString()}, the lowest size we can estimate online.`);
      return;
    }
    if (n > SQFT_MAX) {
      setSqftText(String(SQFT_MAX));
      setLastSqft(SQFT_MAX);
      setSqftMsg(`We set this to ${SQFT_MAX.toLocaleString()}, the highest size we can estimate online.`);
      return;
    }
    setLastSqft(n);
    setSqftMsg("");
  };

  const commitYear = () => {
    const n = parseNum(yearText);
    if (n === null) {
      setYearText(String(lastYear));
      setYearMsg("");
      return;
    }
    if (n < YEAR_MIN || n > currentYear) {
      const fixed = clamp(n, YEAR_MIN, currentYear);
      setYearText(String(fixed));
      setLastYear(fixed);
      setYearMsg(`Year built must be between ${YEAR_MIN} and ${currentYear}.`);
      return;
    }
    setLastYear(n);
    setYearMsg("");
  };

  const onSlider = (e) => {
    const v = Number(e.target.value);
    setSqftText(String(v));
    setLastSqft(v);
    setSqftMsg("");
  };

  const onEnter = (commit) => (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      commit();
    }
  };

  const toggleAddon = (id) =>
    setAddons((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));

  const bookThis = () => {
    const sBad = !sqftValid;
    const yBad = !yearValid;
    if (sBad) commitSqft();
    if (yBad) commitYear();
    if (sBad || yBad) {
      (sBad ? sqftRef : yearRef).current?.focus();
      return;
    }
    sessionStorage.setItem("ridgeline-prefill", JSON.stringify({ sqft: sqftNum, year: yearNum, addons }));
    window.dispatchEvent(new CustomEvent("booking-prefill", { detail: { sqft: sqftNum, year: yearNum, addons } }));
    document.getElementById("book")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="pricing" className="scroll-mt-24 bg-paper py-16 md:py-28" data-testid="pricing-section">
      <div className={container}>
        <div className="grid gap-12 lg:grid-cols-2">
          <Reveal>
            <h2 className="text-[clamp(1.8rem,3.2vw,2.6rem)] font-bold text-navy">{p.title}</h2>
            <div className="mt-8">
              {p.tiers.map((t) => (
                <div key={t.label} className="flex items-baseline justify-between border-b border-line py-3.5">
                  <span className="text-ink">{t.label}</span>
                  <span className="font-heading text-lg font-semibold text-navy">${t.price}</span>
                </div>
              ))}
              <div className="border-b border-line py-3.5">
                <div className="flex items-baseline justify-between">
                  <span className="text-ink">{p.over.label}</span>
                  <span className="font-heading text-lg font-semibold text-navy">${p.over.base}+</span>
                </div>
                <p className="mt-1 text-sm text-slate">{p.over.note}</p>
              </div>
            </div>
            <div className="mt-4 space-y-1 text-sm text-slate">
              {p.ageNotes.map((n) => (
                <p key={n}>{n}</p>
              ))}
            </div>
            <h3 className="mt-8 font-heading text-base font-semibold text-ink">Add-on tests</h3>
            <ul className="mt-3">
              {p.addons.map((a) => (
                <li key={a.id} className="flex items-baseline justify-between border-b border-line/70 py-2.5 text-[15px]">
                  <span className="text-ink">{a.name}</span>
                  <span className="font-semibold text-navy">${a.price}</span>
                </li>
              ))}
            </ul>
          </Reveal>

          <Reveal>
            <div className="rounded-lg border border-line bg-white p-6 transition-[border-color,box-shadow] duration-200 hover:border-[#C9C5BC] hover:shadow-[0_4px_14px_rgba(15,27,39,0.07)] md:p-8" data-testid="calculator-card">
              <h3 className="font-heading text-xl font-semibold text-navy">{p.calculatorTitle}</h3>

              <div className="mt-6">
                <label htmlFor="calc-sqft" className="mb-1.5 block text-sm font-semibold text-ink">
                  Square footage
                </label>
                <div className="flex items-center gap-4">
                  <input
                    id="calc-sqft"
                    ref={sqftRef}
                    data-testid="calc-sqft-input"
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    autoComplete="off"
                    value={sqftText}
                    onChange={(e) => {
                      setSqftText(sanitize(e.target.value, 5));
                      setSqftMsg("");
                    }}
                    onBlur={commitSqft}
                    onKeyDown={onEnter(commitSqft)}
                    className={`${inputCls} w-32`}
                  />
                  <input
                    type="range"
                    aria-label="Square footage slider"
                    data-testid="calc-sqft-slider"
                    min={SQFT_MIN}
                    max={SQFT_MAX}
                    step={50}
                    value={sliderValue}
                    onChange={onSlider}
                    className="h-2 flex-1 accent-[#14283C]"
                  />
                </div>
                {sqftMsg && (
                  <p className="mt-2 text-sm text-slate" role="status" data-testid="calc-sqft-message">
                    {sqftMsg}
                  </p>
                )}
              </div>

              <div className="mt-5">
                <label htmlFor="calc-year" className="mb-1.5 block text-sm font-semibold text-ink">
                  Year built
                </label>
                <input
                  id="calc-year"
                  ref={yearRef}
                  data-testid="calc-year-input"
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  autoComplete="off"
                  value={yearText}
                  onChange={(e) => {
                    setYearText(sanitize(e.target.value, 4));
                    setYearMsg("");
                  }}
                  onBlur={commitYear}
                  onKeyDown={onEnter(commitYear)}
                  className={`${inputCls} w-32`}
                />
                {yearMsg && (
                  <p className="mt-2 text-sm text-slate" role="status" data-testid="calc-year-message">
                    {yearMsg}
                  </p>
                )}
              </div>

              <fieldset className="mt-6">
                <legend className="mb-2 text-sm font-semibold text-ink">Add-on tests</legend>
                <AddonCheckboxes selected={addons} onToggle={toggleAddon} idPrefix="calc" />
              </fieldset>

              <div className="mt-6 border-t border-line pt-5" data-testid="calc-breakdown">
                {estimate ? (
                  <>
                    {estimate.lines.map((l) => (
                      <div key={l.label} className="flex items-baseline justify-between py-1 text-[15px]">
                        <span className="text-slate">{l.label}</span>
                        <span className="text-ink">${l.amount}</span>
                      </div>
                    ))}
                    <div className="mt-3 flex items-baseline justify-between border-t border-line pt-4">
                      <span className="font-heading text-lg font-semibold text-navy">Estimated total</span>
                      <span className="font-heading text-3xl font-bold text-navy" data-testid="calc-total">
                        ${estimate.total}
                      </span>
                    </div>
                    <p className="mt-2 text-sm text-slate">{p.calculatorNote}</p>
                  </>
                ) : (
                  <p className="text-slate" data-testid="calc-empty-message">
                    Enter the size and year built to see an estimate.
                  </p>
                )}
              </div>

              <button
                type="button"
                data-testid="calc-book-button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={bookThis}
                className={`${btnPrimary} mt-6 w-full`}
              >
                {p.calculatorCta}
              </button>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
