import { Link } from "react-router-dom";
import { site } from "../../content/site";
import { Eyebrow, Reveal, SeverityPill, btnPrimary, container } from "../ui-bits";

const teaserFindingIndexes = [3, 4, 0];
const offsets = ["-rotate-1", "rotate-1 -mt-5 lg:ml-10", "-rotate-[0.5deg] -mt-5 lg:ml-4"];

export default function ReportTeaser() {
  const t = site.reportTeaser;
  return (
    <section className="bg-navy py-16 md:py-28" data-testid="report-teaser-section">
      <div className={container}>
        <div className="grid items-center gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <Reveal>
              <Eyebrow dark>{t.eyebrow}</Eyebrow>
              <h2 className="text-[clamp(1.8rem,3.2vw,2.6rem)] font-bold leading-tight text-white">{t.title}</h2>
              <p className="mt-4 text-white/80">{t.text}</p>
              <Link to="/sample-report" data-testid="teaser-open-report-button" className={`${btnPrimary} mt-8`}>
                {t.cta}
              </Link>
            </Reveal>
          </div>
          <div className="lg:col-span-7">
            <Reveal className="mx-auto max-w-md lg:max-w-none">
              {teaserFindingIndexes.map((fi, i) => {
                const f = site.findings[fi];
                return (
                  <article
                    key={f.title}
                    data-testid={`teaser-card-${i}`}
                    className={`flex items-center gap-4 rounded-lg border border-line bg-white p-4 transition-[border-color,box-shadow] duration-200 hover:border-[#C9C5BC] hover:shadow-[0_4px_14px_rgba(15,27,39,0.07)] ${offsets[i]}`}
                  >
                    <img
                      src={f.photo}
                      alt={f.alt}
                      width={1400}
                      height={1050}
                      loading="lazy"
                      className="aspect-[4/3] w-28 shrink-0 rounded-md object-cover sm:w-36"
                    />
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-[0.12em] text-slate">{f.area}</p>
                      <h3 className="mt-1 font-heading text-base font-semibold leading-snug text-ink">{f.title}</h3>
                      <div className="mt-2">
                        <SeverityPill severity={f.severity} testId={`teaser-severity-${i}`} />
                      </div>
                    </div>
                  </article>
                );
              })}
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
