import { site } from "../../content/site";
import { Reveal, Stars, container } from "../ui-bits";

export default function Reviews() {
  const colA = site.reviews.filter((_, i) => i % 2 === 0);
  const colB = site.reviews.filter((_, i) => i % 2 === 1);
  const renderCard = (r, idx) => (
    <figure key={r.name} className="rounded-lg border border-line bg-white p-6 transition-[border-color,box-shadow] duration-200 hover:border-[#C9C5BC] hover:shadow-[0_4px_14px_rgba(15,27,39,0.07)]" data-testid={`review-card-${idx}`}>
      <Stars />
      <blockquote className="mt-3 text-[15px] leading-relaxed text-ink">{r.text}</blockquote>
      <figcaption className="mt-4 text-sm text-slate">
        {r.name}, {r.context}
      </figcaption>
    </figure>
  );
  return (
    <section className="bg-white py-16 md:py-28" data-testid="reviews-section">
      <div className={container}>
        <Reveal>
          <div className="flex flex-wrap items-end gap-x-8 gap-y-3">
            <h2 className="text-[clamp(1.8rem,3.2vw,2.6rem)] font-bold text-navy">What clients say.</h2>
            <p className="flex items-center gap-2.5 pb-1.5 text-[15px] text-slate">
              <Stars />
              <span>
                <strong className="font-semibold text-ink">{site.reviewSummary.rating}</strong>, {site.reviewSummary.count}
              </span>
            </p>
          </div>
        </Reveal>
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          <Reveal className="space-y-6">{colA.map((r) => renderCard(r, site.reviews.indexOf(r)))}</Reveal>
          <Reveal className="space-y-6 md:mt-12">{colB.map((r) => renderCard(r, site.reviews.indexOf(r)))}</Reveal>
        </div>
      </div>
    </section>
  );
}
