import { useEffect, useRef, useState } from "react";
import { ExternalLink } from "lucide-react";
import { site } from "../../content/site";
import { Reveal, container } from "../ui-bits";

export default function ServiceArea() {
  const [mapActive, setMapActive] = useState(false);
  const wrapRef = useRef(null);

  useEffect(() => {
    if (!mapActive) return undefined;
    const onDown = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setMapActive(false);
    };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, [mapActive]);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return undefined;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting) setMapActive(false);
      },
      { threshold: 0.05 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <section className="bg-paper py-16 md:py-28" data-testid="service-area-section">
      <div className={container}>
        <Reveal>
          <h2 className="text-[clamp(1.8rem,3.2vw,2.6rem)] font-bold text-navy">Where we work.</h2>
        </Reveal>
        <div className="mt-10 grid items-start gap-12 lg:grid-cols-2">
          <Reveal>
            <ul className="grid grid-cols-2 gap-x-8 gap-y-3.5 sm:grid-cols-3" data-testid="service-area-list">
              {site.serviceArea.map((c) => (
                <li key={c} className="flex items-center gap-2.5 text-ink">
                  <span className="h-1.5 w-1.5 rounded-full bg-accent" aria-hidden="true" />
                  {c}
                </li>
              ))}
            </ul>
            <p className="mt-8 text-sm text-slate">{site.serviceAreaNote}</p>
          </Reveal>
          <Reveal>
            <p className="mb-3 text-sm text-slate">{site.mapLabel}</p>
            <div
              ref={wrapRef}
              className="relative h-[320px] w-full overflow-hidden rounded-lg border border-line bg-paper lg:aspect-[4/3] lg:h-auto lg:min-h-[380px]"
              data-testid="service-area-map"
            >
              <iframe
                src={site.mapEmbedUrl}
                title={site.mapTitle}
                width="100%"
                height="100%"
                style={{ border: 0 }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                allowFullScreen={false}
                data-testid="map-iframe"
                className={mapActive ? "lg:pointer-events-auto" : "pointer-events-none lg:pointer-events-auto"}
              />
              {!mapActive && (
                <button
                  type="button"
                  data-testid="map-overlay"
                  aria-label="Tap to use the map"
                  onClick={() => setMapActive(true)}
                  className="absolute inset-0 cursor-pointer lg:hidden"
                >
                  <span className="absolute bottom-3 right-3 rounded-md border border-line bg-white px-3 py-2 text-sm font-semibold text-navy">
                    Tap to use the map
                  </span>
                </button>
              )}
            </div>
            <a
              href={site.mapLinkUrl}
              target="_blank"
              rel="noopener noreferrer"
              data-testid="map-open-link"
              className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-navy underline-offset-4 transition-colors duration-200 hover:text-accent-dark hover:underline"
            >
              {site.mapLinkText}
              <ExternalLink className="h-4 w-4" strokeWidth={1.5} aria-hidden="true" />
            </a>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
