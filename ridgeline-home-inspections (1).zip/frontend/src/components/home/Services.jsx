import { Search, ClipboardCheck, Building2, FileCheck, ShieldCheck, Wind, Bug, Video, Thermometer, Waves } from "lucide-react";
import { site } from "../../content/site";
import { Eyebrow, Reveal, container } from "../ui-bits";

const icons = { Search, ClipboardCheck, Building2, FileCheck, ShieldCheck, Wind, Bug, Video, Thermometer, Waves };

export default function Services() {
  const intro = site.servicesIntro;
  return (
    <section id="services" className="scroll-mt-24 bg-paper py-16 md:py-28" data-testid="services-section">
      <div className={container}>
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <Reveal className="lg:sticky lg:top-28">
              <Eyebrow>{intro.eyebrow}</Eyebrow>
              <h2 className="text-[clamp(1.8rem,3.2vw,2.6rem)] font-bold leading-tight text-navy">{intro.title}</h2>
              <p className="mt-4 text-slate">{intro.text}</p>
              <figure className="mt-8 hidden lg:block">
                <img
                  src="/images/thermal-scan.webp"
                  alt="Thermal camera image of a ceiling corner showing a cool patch from missing insulation"
                  width={1400}
                  height={1050}
                  loading="lazy"
                  className="aspect-[4/3] w-full rounded-lg border border-line object-cover"
                />
                <figcaption className="mt-2.5 text-sm text-slate">{intro.thermalCaption}</figcaption>
              </figure>
            </Reveal>
          </div>
          <div className="lg:col-span-8">
            <Reveal>
              <ul className="grid gap-x-10 sm:grid-cols-2">
                {site.services.map((s) => {
                  const Icon = icons[s.icon];
                  return (
                    <li key={s.name} className="group border-t border-line py-6" data-testid={`service-${s.icon.toLowerCase()}`}>
                      <Icon className="h-6 w-6 text-navy transition-colors duration-200 group-hover:text-accent-dark" strokeWidth={1.5} aria-hidden="true" />
                      <h3 className="mt-3 font-heading text-lg font-semibold text-ink">{s.name}</h3>
                      <p className="mt-1.5 text-[15px] leading-relaxed text-slate">{s.text}</p>
                    </li>
                  );
                })}
              </ul>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
