import { site } from "../../content/site";
import { Reveal } from "../ui-bits";

export default function TrustBar() {
  return (
    <section className="border-y border-line bg-white" data-testid="trust-bar" aria-label="Company highlights">
      <div className="mx-auto w-full max-w-content px-5 md:px-8">
        <Reveal>
          <dl className="grid grid-cols-2 gap-y-8 py-8 md:grid-cols-3 lg:grid-cols-5 lg:gap-y-0">
            {site.trustBar.map((item, i) => (
              <div
                key={item.caption}
                className={`flex flex-col px-0 lg:px-6 ${i > 0 ? "lg:border-l lg:border-line" : ""} ${i === 0 ? "lg:pl-0" : ""}`}
              >
                <dt className="order-2 mt-1.5 text-sm text-slate">{item.caption}</dt>
                <dd className="order-1">
                  {item.chip ? (
                    <span className="inline-block rounded-md border border-navy/25 px-2.5 py-1 font-heading text-lg font-bold text-navy">
                      {item.big}
                    </span>
                  ) : (
                    <span className="font-heading text-2xl font-bold text-navy">{item.big}</span>
                  )}
                </dd>
              </div>
            ))}
          </dl>
        </Reveal>
      </div>
    </section>
  );
}
