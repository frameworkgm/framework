import { useEffect, useRef } from "react";

export const btnPrimary =
  "inline-flex min-h-[48px] items-center justify-center gap-2 rounded-md bg-accent px-6 text-base font-semibold text-ink transition-colors duration-200 hover:bg-accent-dark active:bg-accent-dark";
export const btnSecondary =
  "inline-flex min-h-[48px] items-center justify-center gap-2 rounded-md border-[1.5px] border-navy bg-transparent px-6 text-base font-semibold text-navy transition-colors duration-200 hover:bg-navy/5";
export const btnSecondaryDark =
  "inline-flex min-h-[48px] items-center justify-center gap-2 rounded-md border-[1.5px] border-white bg-transparent px-6 text-base font-semibold text-white transition-colors duration-200 hover:bg-white/10";

export function Eyebrow({ children, dark = false }) {
  return (
    <p
      className={`mb-3 flex items-center gap-2.5 text-xs font-semibold uppercase tracking-[0.14em] ${
        dark ? "text-white" : "text-navy"
      }`}
    >
      <span className="inline-block h-[2px] w-6 bg-accent" aria-hidden="true" />
      {children}
    </p>
  );
}

export function Reveal({ children, className = "", as: Tag = "div", ...rest }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return undefined;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      el.classList.add("is-visible");
      return undefined;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            el.classList.add("is-visible");
            io.disconnect();
          }
        });
      },
      { threshold: 0.15 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <Tag ref={ref} className={`reveal ${className}`} {...rest}>
      {children}
    </Tag>
  );
}

const severityMeta = {
  safety: { label: "Safety", dot: "bg-severity-safety" },
  major: { label: "Major", dot: "bg-severity-major" },
  moderate: { label: "Moderate", dot: "bg-severity-moderate" },
  minor: { label: "Minor", dot: "bg-severity-minor" },
};

export function severityLabel(key) {
  return severityMeta[key]?.label || key;
}

export function SeverityPill({ severity, testId }) {
  const meta = severityMeta[severity];
  if (!meta) return null;
  return (
    <span
      data-testid={testId}
      className="inline-flex items-center gap-1.5 rounded-md border border-line bg-white px-2.5 py-1 text-xs font-semibold text-ink"
    >
      <span className={`h-2 w-2 rounded-full ${meta.dot}`} aria-hidden="true" />
      {meta.label}
    </span>
  );
}

export function Stars({ className = "h-4 w-4" }) {
  return (
    <span className="inline-flex items-center gap-0.5" role="img" aria-label="Rated 5 out of 5 stars">
      {[0, 1, 2, 3, 4].map((i) => (
        <svg key={i} viewBox="0 0 20 20" fill="currentColor" className={`${className} text-accent`} aria-hidden="true">
          <path d="M10 1.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L10 14.9l-5.2 2.7 1-5.8L1.5 7.7l5.9-.9L10 1.5z" />
        </svg>
      ))}
    </span>
  );
}

export function usePageMeta(title, description) {
  useEffect(() => {
    document.title = title;
    const m = document.querySelector('meta[name="description"]');
    if (m && description) m.setAttribute("content", description);
  }, [title, description]);
}

export const container = "mx-auto w-full max-w-content px-5 md:px-8";
