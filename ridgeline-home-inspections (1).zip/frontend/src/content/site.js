// Single source of truth for all business-specific content on the site.
// Re-branding the site for another inspector means editing this file (and the Tailwind colors) only.

export const site = {
  businessName: "Ridgeline Home Inspections",
  shortName: "Ridgeline",
  tagline: "Plain-English home inspections",
  phoneDisplay: "(813) 555-0142",
  phoneTel: "+18135550142",
  email: "hello@ridgelineinspections.example",
  city: "Brandon",
  state: "FL",
  region: "Brandon and the greater Tampa Bay area",
  fullLocation: "Brandon, Florida",
  licenseText: "Florida Licensed Home Inspector, License #HI0000 (sample)",
  hours: "Mon to Sat, 7:00 AM to 7:00 PM",
  hoursShort: "Mon to Sat, 7 AM to 7 PM",
  footerDescription:
    "Thorough home inspections with plain-English reports, serving Brandon and the greater Tampa Bay area.",
  conceptNote:
    "Website concept preview. Business details, reviews, prices and photos shown are samples.",

  serviceArea: [
    "Brandon", "Valrico", "Riverview", "Seffner", "Lithia", "Plant City",
    "Tampa", "Apollo Beach", "Ruskin", "Dover", "Thonotosassa", "Wimauma",
  ],
  serviceAreaNote: "Not on the list? Call us. We often travel further.",
  mapLabel: "Service area: Brandon and about 25 miles around it.",
  mapEmbedUrl: "https://www.google.com/maps?q=Brandon,+Florida&z=10&output=embed",
  mapLinkUrl: "https://www.google.com/maps?q=Brandon,+Florida",
  mapLinkText: "Open in Google Maps",
  mapTitle: "Map of the Brandon, Florida service area",

  nav: [
    { label: "Services", to: "/#services" },
    { label: "Why us", to: "/#different" },
    { label: "Sample report", to: "/sample-report", page: "/sample-report" },
    { label: "Pricing", to: "/#pricing" },
    { label: "For agents", to: "/agents", page: "/agents" },
    { label: "FAQ", to: "/#faq" },
  ],
  footerLinks: [
    { label: "Services", to: "/#services" },
    { label: "Sample report", to: "/sample-report" },
    { label: "Pricing", to: "/#pricing" },
    { label: "For agents", to: "/agents" },
    { label: "FAQ", to: "/#faq" },
    { label: "Book", to: "/#book" },
  ],

  hero: {
    eyebrow: "Home inspections in Brandon, Florida",
    title: "Know the house before you sign.",
    subtext:
      "A thorough inspection and a plain-English report with photos of every finding, in your inbox within 24 hours.",
    primaryCta: "Book an inspection",
    secondaryCta: "See a sample report",
    note: "Most inspections can be scheduled within 2 to 3 days.",
  },

  trustBar: [
    { big: "1,400+", caption: "inspections completed" },
    { big: "24 hours", caption: "report turnaround" },
    { big: "4.9 / 5", caption: "from 212 Google reviews" },
    { big: "Licensed", caption: "and fully insured", chip: true },
    { big: "InterNACHI", caption: "Certified Professional Inspector", chip: true },
  ],

  servicesIntro: {
    eyebrow: "What we inspect",
    title: "Every system in the house, checked and photographed.",
    text: "A standard inspection takes 2 to 3 hours. We go through the roof, attic, structure, plumbing, electrical, heating and cooling, and the exterior. Insurance inspections and add-on tests are done during the same visit.",
    thermalCaption: "Thermal imaging add-on. The cool patch on this ceiling turned out to be missing insulation.",
  },
  services: [
    { icon: "Search", name: "General home inspection", text: "A top-to-bottom review of the roof, structure, electrical, plumbing, HVAC, insulation and exterior." },
    { icon: "ClipboardCheck", name: "Pre-listing inspection", text: "Find the problems before buyers do, so there are no surprises mid-sale." },
    { icon: "Building2", name: "New construction and 11-month warranty", text: "Independent review of a new build, or a check before your builder's warranty runs out." },
    { icon: "FileCheck", name: "4-Point inspection", text: "A focused review of the roof, electrical, plumbing and HVAC. Many Florida insurers ask for it on older homes." },
    { icon: "ShieldCheck", name: "Wind mitigation inspection", text: "Documents roof shape, roof-to-wall connections and opening protection. The report can support a lower insurance premium." },
    { icon: "Wind", name: "Radon testing", text: "A 48-hour test with continuous monitoring and a clear result." },
    { icon: "Bug", name: "Wood-destroying insect inspection", text: "Termites, carpenter ants and other insect damage, documented with photos." },
    { icon: "Video", name: "Sewer scope", text: "A camera run through the main line to catch cracks, roots and blockages." },
    { icon: "Thermometer", name: "Thermal imaging", text: "An infrared scan that shows moisture, missing insulation and hot spots you cannot see." },
    { icon: "Waves", name: "Pool and spa", text: "Equipment, safety barriers, bonding and visible condition of the pool or spa." },
  ],

  different: {
    eyebrow: "Why Ridgeline",
    title: "What makes us different?",
    text: "Most inspectors find the same problems. What changes is how clearly you hear about them, how fast, and who is on the other side of the table.",
    linkText: "See a sample report",
    rows: [
      {
        title: "A report you can read.",
        body: "Every finding comes with a photo, a plain explanation, a severity rating and a rough cost range. No copy-pasted paragraphs of jargon, no 60-page wall of text.",
        caption: "PHOTO ON EVERY FINDING",
      },
      {
        title: "Reports in 24 hours.",
        body: "You will usually have the report the same evening. Inspection periods in Florida are short, and waiting for paperwork should never be the reason you lose days.",
        caption: "USUALLY SAME EVENING",
      },
      {
        title: "Walk the house with us.",
        body: "We save the last stretch of the visit to go through the main findings with you in person, with the problem right in front of you. You leave knowing what matters and what does not.",
        caption: "YOU ARE WELCOME TO ATTEND",
      },
      {
        title: "We inspect. We never repair.",
        body: "We do not sell repairs and we do not take referral fees from contractors. Our only job is to tell you what is there, so you can trust that nothing is padded.",
        caption: "NO CONFLICT OF INTEREST",
      },
      {
        title: "Built for Florida homes.",
        body: "Roof age and condition, wind resistance, slab-on-grade foundations, moisture and pests are the things that decide a Florida purchase. We look at them every day, and we offer the 4-Point and wind mitigation inspections insurers ask for.",
        caption: "4-POINT AND WIND MITIGATION",
      },
      {
        title: "We answer after the inspection.",
        body: "Reading a report at 9 PM raises questions. Call or text us for 30 days after the inspection and we will walk you through anything, at no charge.",
        caption: "30 DAYS OF FOLLOW-UP",
      },
    ],
    closingPre: "Want the details?",
    closingLink: "Open the sample report",
    closingMid: ", or call",
  },

  demoNotice: {
    text: "This is a modern demo template for home inspectors.",
    sub: "Want a site like this customized with your branding, local service area, and pricing?",
    cta: "Request your site",
    ctaTo: "/#book",
  },

  inspector: {
    eyebrow: "Meet your inspector",
    title: "The person behind the report.",
    name: "Jordan Ellis",
    role: "Owner and lead inspector",
    story: "Jordan started in residential construction before moving into inspections twelve years ago. He has walked more than 1,400 roofs, attics and crawlspaces across the Tampa Bay area, and he writes every report himself. When you call with a question after the inspection, he is the one who answers.",
    years: "12 years of inspection experience",
    homes: "1,400+ homes inspected",
    photo: "/images/inspector-ladder.webp",
    alt: "Home inspector in a hard hat on a ladder at the edge of a shingle roof, seen from behind",
  },

  agentsRoi: {
    stat: "3x",
    statLabel: "up to 3x faster closings",
    title: "How much time does a poor report cost you?",
    text: "A report that arrives three days late, or reads like a legal document, stalls a negotiation. Fast scheduling, clean formatting and a 24-hour turnaround keep the deal moving and the buyer calm.",
    points: [
      "Scheduling confirmed within the hour during business hours",
      "Report delivered within 24 hours, usually the same evening",
      "Findings written for buyers, with severity and cost ranges",
    ],
  },

  reportTeaser: {
    eyebrow: "The report is the product",
    title: "See exactly what you get before you book.",
    text: "Every finding has a photo, a severity rating, a plain explanation and a rough repair cost range. No 60-page wall of jargon.",
    cta: "Open the sample report",
  },

  steps: [
    { title: "Book online or call.", text: "Pick a day. We confirm within the hour during business hours." },
    { title: "We inspect.", text: "About 2 to 3 hours on site. You are welcome to walk through with us and ask questions." },
    { title: "Report in 24 hours.", text: "Photos, severity ratings, plain explanations and a one-page summary." },
  ],

  pricing: {
    title: "Straightforward pricing.",
    tiers: [
      { maxSqft: 1500, label: "Up to 1,500 sq ft", price: 325 },
      { maxSqft: 2000, label: "1,501 to 2,000 sq ft", price: 375 },
      { maxSqft: 2500, label: "2,001 to 2,500 sq ft", price: 425 },
      { maxSqft: 3000, label: "2,501 to 3,000 sq ft", price: 475 },
      { maxSqft: 3500, label: "3,001 to 3,500 sq ft", price: 525 },
      { maxSqft: 4000, label: "3,501 to 4,000 sq ft", price: 585 },
    ],
    over: {
      label: "Over 4,000 sq ft",
      note: "$585 plus $50 per additional 500 sq ft (rounded up)",
      base: 585,
      stepSqft: 500,
      stepFee: 50,
    },
    ageNotes: [
      "Homes built before 1980: add $50.",
      "Homes built before 1950: add $100 (instead of the $50).",
    ],
    addons: [
      { id: "radon", name: "Radon testing", price: 150 },
      { id: "wdi", name: "Wood-destroying insect inspection", price: 85 },
      { id: "sewer", name: "Sewer scope", price: 175 },
      { id: "fourpoint", name: "4-Point inspection", price: 150 },
      { id: "windmit", name: "Wind mitigation inspection", price: 100 },
      { id: "pool", name: "Pool and spa", price: 100 },
      { id: "thermal", name: "Thermal imaging", price: 75 },
      { id: "outbuilding", name: "Detached garage or outbuilding", price: 75 },
    ],
    sqftMin: 500,
    sqftMax: 10000,
    yearMin: 1850,
    calculatorTitle: "Estimate your inspection",
    calculatorNote: "Estimate only. The final price is confirmed when we schedule.",
    calculatorCta: "Book this inspection",
  },

  reviewSummary: { rating: "4.9 out of 5", count: "212 Google reviews" },
  reviews: [
    { text: "He found a slow leak under the upstairs bathroom that two other inspectors had missed on a house we almost bought. The photos made it easy to negotiate.", name: "Daniel R.", context: "Buyer, 1998 two-story" },
    { text: "I did not understand half of what the last report said. This one used plain words and told me what to fix first and what could wait.", name: "Priya S.", context: "First-time buyer, 2004 townhome" },
    { text: "Report was in my email by the next morning. Our agent had it before I finished my coffee.", name: "Marcus T.", context: "Buyer, 1976 ranch" },
    { text: "He walked me through the whole attic and showed me the insulation problem in person. Never felt rushed.", name: "Linda K.", context: "Buyer, 1989 split-level" },
    { text: "Got a pre-listing inspection and fixed three things before listing. Sold in 9 days with no renegotiation.", name: "Tom and Beth H.", context: "Seller, 1992 colonial" },
    { text: "Showed up on time, polite, careful. The sewer scope caught a root problem that would have cost us thousands.", name: "Andre W.", context: "Buyer, 1961 block ranch" },
  ],

  agentsBand: {
    title: "Real estate agent? We keep your deals moving.",
    text: "Fast scheduling, reports in 24 hours, calm and clear wording.",
    cta: "See what agents get",
  },

  faqSection: {
    title: "Questions we hear a lot.",
    subPrefix: "Can't find yours? Call or text",
    searchPlaceholder: "Search questions",
    noMatchPrefix: "No match. Call us at",
    noMatchSuffix: "and we will answer it.",
    categories: ["Booking", "Inspection day", "Your report", "Florida homes", "Price and payment"],
    ctaTitle: "Still have a question?",
    ctaPrimary: "Book an inspection",
    ctaCallPrefix: "Call",
    items: [
      { c: "Booking", q: "How soon can you inspect?", a: "Most inspections can be scheduled within 2 to 3 days. Florida contracts usually give a buyer a short inspection period, often 10 to 15 days, so book as soon as you are under contract. If you are short on time, call us and we will look for an earlier slot." },
      { c: "Booking", q: "How do I book?", a: "Fill out the form on this page or call us. We confirm by phone or text within the hour during business hours, Monday to Saturday, 7 AM to 7 PM." },
      { c: "Booking", q: "What do you need from me to book?", a: "The property address, the rough size and year built, and a day that works. If you are working with an agent, we coordinate access with them directly." },
      { c: "Booking", q: "Can I reschedule?", a: "Yes. Let us know at least 24 hours ahead and we will move it with no fee. For same-day changes, call us and we will do what we can." },
      { c: "Inspection day", q: "Do I need to be there?", a: "No, but it helps. You are welcome to join for the last hour, when we walk through the findings together and you can ask questions." },
      { c: "Inspection day", q: "How long does it take?", a: "Most homes take 2 to 3 hours. Larger or older homes, pools and add-on tests can take longer. We do not rush to hit a time." },
      { c: "Inspection day", q: "How should I prepare?", a: "Make sure water, electricity and gas (if the home has it) are on. Clear access to the electrical panel, water heater, attic hatch and the air handler. If you are the seller, please secure pets." },
      { c: "Inspection day", q: "What do you inspect?", a: "The roof, attic, structure, exterior, windows and doors, plumbing, electrical, heating and cooling, insulation and ventilation, and the visible parts of the interior. We test what can be safely tested and report what we find." },
      { c: "Inspection day", q: "What is not covered?", a: "We inspect what is visible and accessible. We do not open walls, move furniture or test hidden systems. Anything we could not see is noted in the report so nothing is left unclear." },
      { c: "Inspection day", q: "Can my agent attend?", a: "Yes. Agents are welcome and we are happy to explain findings to them directly." },
      { c: "Inspection day", q: "Do you do repairs?", a: "No. We only inspect, so we have no reason to find problems that are not there." },
      { c: "Your report", q: "When do I get the report?", a: "Within 24 hours of the inspection, usually the same evening. It arrives as a link and a PDF." },
      { c: "Your report", q: "What does the report look like?", a: "Every finding has a photo, a severity rating (Safety, Major, Moderate or Minor), a plain explanation of what we found and why it matters, what to do about it, and a rough cost range. You can see a real example on the sample report page." },
      { c: "Your report", q: "What if you find something serious?", a: "We tell you on site, show you the photo, and explain what it means in plain words. We do not tell you whether to buy the house. We tell you what is there so you can decide." },
      { c: "Your report", q: "Can I call you with questions after the inspection?", a: "Yes. Call or text us for 30 days after the inspection at no charge. We would rather answer a question than have you guess." },
      { c: "Florida homes", q: "What is a 4-Point inspection and do I need one?", a: "It is a short, focused review of the roof, electrical system, plumbing and HVAC. Many Florida insurers ask for it on older homes, often those 20 to 30 years old or more, before they will write or renew a policy. Check with your insurance agent, and if they ask for it, we can do it during the same visit." },
      { c: "Florida homes", q: "What is a wind mitigation inspection?", a: "We document features that help a home resist wind, such as roof shape, how the roof is attached to the walls, and protection for windows and doors. Insurers in Florida may offer a discount for these features. The report is what your insurance agent uses. We do not set the discount." },
      { c: "Florida homes", q: "Do you test for mold?", a: "We note visible signs of moisture and suspected mold growth and photograph them. In Florida, mold testing and assessment require a separate state mold assessor license, so if we see signs we refer you to a licensed assessor." },
      { c: "Florida homes", q: "Do you check for termites?", a: "Yes. A wood-destroying organism (WDO) inspection is available as an add-on. In Florida it is performed by a licensed pest control professional, and we coordinate it into the same visit whenever possible." },
      { c: "Florida homes", q: "What if the roof is too steep or unsafe to walk?", a: "We walk the roof when it is safe. When it is not, we use a drone or inspect from a ladder and binoculars, and the report states exactly how the roof was viewed and what the limits were." },
      { c: "Florida homes", q: "Are you licensed and insured?", a: "Yes. We are licensed by the State of Florida and carry errors and omissions and general liability insurance. Our license number is on every report." },
      { c: "Price and payment", q: "How much does an inspection cost?", a: "Standard inspections start at $325 and depend on the size and age of the home. Use the calculator on this page for an estimate." },
      { c: "Price and payment", q: "How do I pay?", a: "At the end of the inspection, by card, check or digital payment. Report delivery does not wait on payment." },
      { c: "Price and payment", q: "Do you charge extra for older homes?", a: "Homes built before 1980 add $50, and homes built before 1950 add $100. Older homes take longer to go through carefully." },
    ],
  },

  booking: {
    title: "Book your inspection.",
    text: "Tell us about the property and when you want us there. We will confirm by phone or text within the hour during business hours.",
    submitLabel: "Request this inspection",
    successTitle: "Thanks. Request received.",
    successNote: "We will contact you within the hour during business hours (Mon to Sat, 7 AM to 7 PM).",
    propertyTypes: ["Single-family", "Condo", "Townhome", "Multi-family", "Manufactured home"],
    timeOptions: ["Morning", "Afternoon", "Flexible"],
    agentCheckbox: "I am a real estate agent booking for my client",
    cityZipPlaceholder: "Brandon, FL 33511",
  },

  reportMeta: {
    eyebrow: "Sample inspection report",
    address: "1827 Palmetto Ridge Drive",
    subline: "Brandon, FL 33511. Single-family, built 1994, 2,150 sq ft, 3 bed, 2 bath. Inspected on a clear day, 86°F.",
    inspector: "Inspector: Jordan Ellis, License #HI0000 (sample)",
    delivered: "Report delivered: 6 hours after inspection",
    summaryNote: "This is a shortened sample with ten findings. A full report also covers every system that was inspected without problems.",
    closingTitle: "This is what you get on every inspection.",
    closingText: "Photos, plain explanations, severity ratings and cost ranges. No jargon.",
    closingCta: "Book an inspection",
  },

  findings: [
    {
      area: "Roof", title: "Worn shingles on the south slope", severity: "moderate",
      photo: "/images/finding-roof-shingles.webp",
      alt: "Asphalt shingle roof slope with granule loss, lifted tabs and moss streaks near the edge",
      found: "Granule loss and several lifted tabs across the lower third of the south slope.",
      why: "Exposed shingles age faster and can let wind-driven rain get underneath.",
      todo: "Have a roofer seal or replace the lifted tabs. Budget for a full replacement within 3 to 5 years.",
      cost: "$350 to $900 for repairs.",
    },
    {
      area: "Roof", title: "Failing flashing at the chimney", severity: "major",
      photo: "/images/finding-chimney-flashing.webp",
      alt: "Brick chimney with rusted step flashing and cracked sealant where it meets the roof",
      found: "Rusted step flashing and cracked sealant at the base of the chimney.",
      why: "This is a common point of water entry during heavy rain and can damage the framing below.",
      todo: "Have a licensed roofer re-flash and reseal the chimney.",
      cost: "$400 to $1,200.",
    },
    {
      area: "Attic", title: "Thin and uneven insulation", severity: "minor",
      photo: "/images/finding-attic-insulation.webp",
      alt: "Attic floor with thin, compressed blown-in insulation and bare spots between the joists",
      found: "Average depth is about 4 inches, compressed near the eaves, with bare spots between joists.",
      why: "Higher heating and cooling bills and a less comfortable house.",
      todo: "Add blown-in insulation to reach the recommended depth and install baffles at the eaves.",
      cost: "$1,200 to $2,400.",
    },
    {
      area: "Hall bathroom", title: "Water stain on the ceiling", severity: "major",
      photo: "/images/finding-ceiling-stain.webp",
      alt: "Bathroom ceiling with a tan-brown water stain near the light fixture",
      found: "A stain about 14 inches wide near the light fixture. The moisture meter reading was elevated.",
      why: "The source is likely above, either a supply line or the roof. Painting over it will not fix it.",
      todo: "Find and repair the source first, then repair and repaint the ceiling.",
      cost: "$200 to $2,500 depending on the cause.",
    },
    {
      area: "Electrical", title: "Double-tapped breakers and a missing knockout cover", severity: "safety",
      photo: "/images/finding-electrical-panel.webp",
      alt: "Open breaker panel with two wires under one breaker screw and an open knockout hole",
      found: "Two breakers each feed two circuits, and there is an open hole in the panel enclosure.",
      why: "Breakers are designed for one wire. Loose connections can overheat and start a fire.",
      todo: "Have a licensed electrician separate the circuits and close the opening.",
      cost: "$150 to $400.",
    },
    {
      area: "Kitchen", title: "No ground-fault protection near the sink", severity: "safety",
      photo: "/images/finding-kitchen-outlet.webp",
      alt: "Standard wall outlet on a kitchen backsplash near the sink, with no GFCI buttons",
      found: "A standard outlet within 2 feet of the sink with no GFCI protection.",
      why: "Water and electricity together raise the risk of shock.",
      todo: "Replace with a GFCI outlet or protect the circuit with a GFCI breaker.",
      cost: "$75 to $200.",
    },
    {
      area: "Garage", title: "Water heater with no drain pan and a short discharge pipe", severity: "moderate",
      photo: "/images/finding-water-heater.webp",
      alt: "Tank water heater in a garage corner with no drain pan and a short discharge pipe",
      found: "The tank is about 14 years old, has no drain pan, and the discharge pipe stops about 8 inches above the floor.",
      why: "Older tanks fail with little warning, and a short discharge pipe can spray hot water.",
      todo: "Correct the discharge pipe now and plan to replace the unit.",
      cost: "$1,200 to $2,000 for replacement.",
    },
    {
      area: "Garage", title: "Hairline crack in the slab", severity: "moderate",
      photo: "/images/finding-foundation-crack.webp",
      alt: "Hairline crack in a concrete garage slab near the corner of a block wall",
      found: "A hairline crack about the width of a pencil line near the corner. No vertical movement between the sides.",
      why: "Most cracks like this come from normal concrete shrinkage, but it should be watched.",
      todo: "Seal the crack and mark its ends with a pencil. If it widens or shifts, call a structural engineer.",
      cost: "$0 to $600.",
    },
    {
      area: "Exterior", title: "Air conditioner condenser needs service", severity: "moderate",
      photo: "/images/finding-hvac-condenser.webp",
      alt: "Outdoor air conditioner condenser with coils clogged with leaves and rust at the base",
      found: "Coils clogged with debris, bent fins and rust at the base. The unit is about 16 years old.",
      why: "A dirty condenser works harder and fails sooner, especially on older units.",
      todo: "Have an HVAC technician clean and service it, and plan for replacement within a few years.",
      cost: "$150 to $250 for service.",
    },
    {
      area: "Exterior", title: "Soil slopes toward the house", severity: "moderate",
      photo: "/images/finding-grading.webp",
      alt: "Side of a house with soil sloping toward the foundation and a downspout ending at the wall",
      found: "On the east side the soil slopes toward the foundation, with splash marks on the siding and a downspout that ends at the wall.",
      why: "Water collecting at the slab edge can lead to rot in lower trim and siding, erosion, and more pest pressure over time.",
      todo: "Regrade so the soil slopes away about 6 inches over 10 feet, and extend the downspout at least 6 feet.",
      cost: "$500 to $2,000.",
    },
  ],

  agentsPage: {
    eyebrow: "For real estate agents",
    title: "Inspections that do not slow your deal down.",
    subtext: "Quick scheduling, reports in 24 hours, and wording your clients can actually understand.",
    cta: "Request an inspection for a client",
    blocks: [
      { num: "24 hrs", title: "Report turnaround", text: "Often the same evening, so you can keep negotiations moving." },
      { num: "Clear, calm wording", title: "", text: "We describe what is there. We do not scare clients or kill deals. Every finding has a severity and a rough cost range, so your client can decide." },
      { num: "Easy booking", title: "", text: "Send us the client's details and the property address. We handle scheduling directly with the client and keep you updated." },
    ],
    stepsTitle: "How a booking works",
    steps: [
      "You send the details",
      "We contact your client within the hour",
      "Inspection, with you welcome to attend",
      "Report to you and your client within 24 hours",
    ],
    quote: {
      text: "The report is something I can send straight to my buyers. They understand it, and it saves me an hour of explaining.",
      name: "Sample agent, Brandon brokerage",
    },
    formTitle: "Request an inspection for a client",
    submitLabel: "Send request",
    successTitle: "Thanks. Request received.",
    successNote: "We will contact you within the hour during business hours (Mon to Sat, 7 AM to 7 PM).",
    callBand: "Prefer to call?",
  },
};

export function computeEstimate(sqft, year, addonIds) {
  const p = site.pricing;
  const lines = [];
  const tier = p.tiers.find((t) => sqft <= t.maxSqft);
  if (tier) {
    lines.push({ label: `Base, ${tier.label.toLowerCase()}`, amount: tier.price });
  } else {
    const extra = Math.ceil((sqft - p.tiers[p.tiers.length - 1].maxSqft) / p.over.stepSqft);
    lines.push({ label: `Base, ${p.over.label.toLowerCase()}`, amount: p.over.base + p.over.stepFee * extra });
  }
  if (year && year < 1950) {
    lines.push({ label: "Built before 1950", amount: 100 });
  } else if (year && year < 1980) {
    lines.push({ label: "Built before 1980", amount: 50 });
  }
  (addonIds || []).forEach((id) => {
    const a = p.addons.find((x) => x.id === id);
    if (a) lines.push({ label: a.name, amount: a.price });
  });
  return { lines, total: lines.reduce((s, l) => s + l.amount, 0) };
}
