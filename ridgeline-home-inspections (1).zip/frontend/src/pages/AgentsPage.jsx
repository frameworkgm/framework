import { useState } from "react";
import axios from "axios";
import { Phone } from "lucide-react";
import { site } from "../content/site";
import AgentsRoi from "../components/AgentsRoi";
import { Eyebrow, Reveal, btnPrimary, container, usePageMeta } from "../components/ui-bits";
import { Field, Honeypot, inputCls, isEmail, isPhone } from "../components/forms";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;
const empty = {
  agentName: "", brokerage: "", phone: "", email: "", clientName: "",
  propertyAddress: "", requestedDate: "", notes: "", website: "",
};

export default function AgentsPage() {
  usePageMeta(
    "For Real Estate Agents | Ridgeline Home Inspections, Brandon FL",
    "Fast scheduling, reports in 24 hours, and calm, clear wording your clients can understand. Book an inspection for a client."
  );
  const a = site.agentsPage;
  const [form, setForm] = useState(empty);
  const [errors, setErrors] = useState({});
  const [sending, setSending] = useState(false);
  const [reference, setReference] = useState("");
  const [submitError, setSubmitError] = useState("");
  const today = new Date().toISOString().split("T")[0];

  const set = (k) => (e) => {
    setForm((f) => ({ ...f, [k]: e.target.value }));
    setErrors((er) => ({ ...er, [k]: "" }));
  };

  const validate = () => {
    const er = {};
    if (!form.agentName.trim()) er.agentName = "Please enter your name.";
    if (!form.brokerage.trim()) er.brokerage = "Please enter your brokerage.";
    if (!isPhone(form.phone)) er.phone = "Please enter a phone number we can reach you on.";
    if (!isEmail(form.email)) er.email = "Please enter a valid email address.";
    if (!form.clientName.trim()) er.clientName = "Please enter your client's name.";
    if (!form.propertyAddress.trim()) er.propertyAddress = "Please enter the property address.";
    if (!form.requestedDate) er.requestedDate = "Please pick a requested date.";
    else if (form.requestedDate < today) er.requestedDate = "Please pick a date that is not in the past.";
    return er;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    setSubmitError("");
    const er = validate();
    setErrors(er);
    if (Object.keys(er).length) return;
    setSending(true);
    try {
      const res = await axios.post(`${API}/agent-requests`, {
        agentName: form.agentName.trim(),
        brokerage: form.brokerage.trim(),
        phone: form.phone.trim(),
        email: form.email.trim(),
        clientName: form.clientName.trim(),
        propertyAddress: form.propertyAddress.trim(),
        requestedDate: form.requestedDate,
        notes: form.notes.trim(),
        website: form.website,
      });
      setReference(res.data.reference);
    } catch {
      setSubmitError(`Something went wrong on our end. Your details are still here. Please try again, or call us at ${site.phoneDisplay}.`);
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      <section className="bg-navy py-16 md:py-28" data-testid="agents-hero">
        <div className={container}>
          <Reveal>
            <Eyebrow dark>{a.eyebrow}</Eyebrow>
            <h1 className="max-w-2xl text-[clamp(2.4rem,5vw,4rem)] font-bold leading-[1.08] text-white">{a.title}</h1>
            <p className="mt-5 max-w-xl text-base text-white/80 md:text-lg">{a.subtext}</p>
            <a href="#agent-form" data-testid="agents-hero-button" className={`${btnPrimary} mt-8`}>
              {a.cta}
            </a>
          </Reveal>
        </div>
      </section>

      <AgentsRoi />

      <section className="bg-paper py-16 md:py-28" data-testid="agents-benefits">
        <div className={container}>
          {a.blocks.map((b, i) => (
            <Reveal key={b.num} className={`grid gap-4 border-t border-line py-10 sm:grid-cols-[200px_1fr] sm:gap-10 ${i === a.blocks.length - 1 ? "border-b" : ""}`}>
              <p className="font-heading text-3xl font-bold leading-tight text-navy md:text-4xl">{b.num}</p>
              <div className={i === 1 ? "max-w-xl" : "max-w-md"}>
                {b.title ? <h2 className="font-heading text-xl font-semibold text-ink">{b.title}</h2> : null}
                <p className={`text-slate ${b.title ? "mt-2" : ""}`}>{b.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="bg-white py-16 md:py-28" data-testid="agents-steps">
        <div className={container}>
          <Reveal>
            <h2 className="text-[clamp(1.8rem,3.2vw,2.6rem)] font-bold text-navy">{a.stepsTitle}</h2>
          </Reveal>
          <ol className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {a.steps.map((s, i) => (
              <Reveal as="li" key={s} className="border-t-2 border-navy pt-5">
                <span className="font-heading text-sm font-bold text-accent-dark">Step {i + 1}</span>
                <p className="mt-2 font-heading text-lg font-semibold leading-snug text-ink">{s}</p>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      <section className="bg-paper py-16 md:py-20" data-testid="agents-quote">
        <div className={container}>
          <Reveal>
            <blockquote className="max-w-3xl border-l-4 border-accent pl-6 md:pl-8">
              <p className="font-heading text-xl font-semibold leading-relaxed text-navy md:text-2xl">
                &ldquo;{a.quote.text}&rdquo;
              </p>
              <cite className="mt-4 block text-sm not-italic text-slate">{a.quote.name}</cite>
            </blockquote>
          </Reveal>
        </div>
      </section>

      <section id="agent-form" className="scroll-mt-24 bg-paper pb-16 md:pb-24" data-testid="agent-form-section">
        <div className={container}>
          <Reveal>
            <h2 className="text-[clamp(1.8rem,3.2vw,2.6rem)] font-bold text-navy">{a.formTitle}</h2>
            <div className="mt-8 rounded-lg border border-line bg-white p-6 md:p-8" aria-live="polite">
              {reference ? (
                <div data-testid="agent-success" className="fade-in">
                  <h3 className="font-heading text-2xl font-bold text-navy">{a.successTitle}</h3>
                  <p className="mt-3 text-ink">
                    Your reference: <strong className="font-semibold" data-testid="agent-reference">{reference}</strong>
                  </p>
                  <p className="mt-2 text-slate">{a.successNote}</p>
                </div>
              ) : (
                <form onSubmit={onSubmit} noValidate data-testid="agent-form" className="relative">
                  <div className="grid gap-5 sm:grid-cols-2">
                    <Field label="Agent name" id="ag-name" required error={errors.agentName}>
                      <input id="ag-name" data-testid="agent-name-input" className={inputCls} value={form.agentName} onChange={set("agentName")} autoComplete="name" aria-invalid={!!errors.agentName} aria-describedby={errors.agentName ? "ag-name-error" : undefined} />
                    </Field>
                    <Field label="Brokerage" id="ag-brokerage" required error={errors.brokerage}>
                      <input id="ag-brokerage" data-testid="agent-brokerage-input" className={inputCls} value={form.brokerage} onChange={set("brokerage")} autoComplete="organization" aria-invalid={!!errors.brokerage} aria-describedby={errors.brokerage ? "ag-brokerage-error" : undefined} />
                    </Field>
                    <Field label="Phone" id="ag-phone" required error={errors.phone}>
                      <input id="ag-phone" data-testid="agent-phone-input" type="tel" className={inputCls} value={form.phone} onChange={set("phone")} autoComplete="tel" aria-invalid={!!errors.phone} aria-describedby={errors.phone ? "ag-phone-error" : undefined} />
                    </Field>
                    <Field label="Email" id="ag-email" required error={errors.email}>
                      <input id="ag-email" data-testid="agent-email-input" type="email" className={inputCls} value={form.email} onChange={set("email")} autoComplete="email" aria-invalid={!!errors.email} aria-describedby={errors.email ? "ag-email-error" : undefined} />
                    </Field>
                    <Field label="Client name" id="ag-client" required error={errors.clientName}>
                      <input id="ag-client" data-testid="agent-client-input" className={inputCls} value={form.clientName} onChange={set("clientName")} aria-invalid={!!errors.clientName} aria-describedby={errors.clientName ? "ag-client-error" : undefined} />
                    </Field>
                    <Field label="Property address" id="ag-address" required error={errors.propertyAddress}>
                      <input id="ag-address" data-testid="agent-address-input" className={inputCls} value={form.propertyAddress} onChange={set("propertyAddress")} autoComplete="street-address" aria-invalid={!!errors.propertyAddress} aria-describedby={errors.propertyAddress ? "ag-address-error" : undefined} />
                    </Field>
                    <Field label="Requested date" id="ag-date" required error={errors.requestedDate}>
                      <input id="ag-date" data-testid="agent-date-input" type="date" min={today} className={inputCls} value={form.requestedDate} onChange={set("requestedDate")} aria-invalid={!!errors.requestedDate} aria-describedby={errors.requestedDate ? "ag-date-error" : undefined} />
                    </Field>
                    <Field label="Notes (optional)" id="ag-notes" className="sm:col-span-2">
                      <textarea id="ag-notes" data-testid="agent-notes-input" rows={3} className={`${inputCls} min-h-0`} value={form.notes} onChange={set("notes")} />
                    </Field>
                  </div>
                  <Honeypot value={form.website} onChange={(v) => setForm((f) => ({ ...f, website: v }))} />
                  {submitError && (
                    <p role="alert" data-testid="agent-error" className="mt-4 rounded-md border border-severity-safety/30 bg-severity-safety/5 px-4 py-3 text-sm text-severity-safety">
                      {submitError}
                    </p>
                  )}
                  <button type="submit" data-testid="agent-submit-button" disabled={sending} className={`${btnPrimary} mt-6 w-full disabled:cursor-not-allowed disabled:opacity-60 sm:w-auto`}>
                    {sending ? "Sending..." : a.submitLabel}
                  </button>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </section>

      <section className="bg-navy py-14" data-testid="agents-call-band">
        <div className={`${container} flex flex-wrap items-center gap-x-4 gap-y-2`}>
          <p className="font-heading text-xl font-semibold text-white">{a.callBand}</p>
          <a
            href={`tel:${site.phoneTel}`}
            data-testid="agents-call-link"
            className="inline-flex items-center gap-2 font-heading text-xl font-bold text-accent hover:text-white"
          >
            <Phone className="h-5 w-5" strokeWidth={1.5} aria-hidden="true" />
            {site.phoneDisplay}
          </a>
        </div>
      </section>
    </>
  );
}
