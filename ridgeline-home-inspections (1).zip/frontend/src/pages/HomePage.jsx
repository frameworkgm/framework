import Hero from "../components/home/Hero";
import TrustBar from "../components/home/TrustBar";
import Services from "../components/home/Services";
import Different from "../components/home/Different";
import Inspector from "../components/home/Inspector";
import ReportTeaser from "../components/home/ReportTeaser";
import HowItWorks from "../components/home/HowItWorks";
import Pricing from "../components/home/Pricing";
import Reviews from "../components/home/Reviews";
import AgentsBand from "../components/home/AgentsBand";
import ServiceArea from "../components/home/ServiceArea";
import Faq from "../components/home/Faq";
import Booking from "../components/home/Booking";
import { usePageMeta } from "../components/ui-bits";
import { site } from "../content/site";

export default function HomePage() {
  usePageMeta(
    `${site.businessName} | ${site.city}, ${site.state}`,
    `Home inspections in ${site.fullLocation} and the greater Tampa Bay area. Thorough inspections, plain-English reports with photos, delivered within 24 hours.`
  );

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "HomeAndConstructionBusiness",
    name: site.businessName,
    description: site.footerDescription,
    telephone: site.phoneTel,
    email: site.email,
    address: {
      "@type": "PostalAddress",
      addressLocality: site.city,
      addressRegion: site.state,
      postalCode: "33511",
      addressCountry: "US",
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: 27.9378,
      longitude: -82.2859,
    },
    areaServed: site.serviceArea,
    openingHours: "Mo-Sa 07:00-19:00",
    image: "/images/hero-exterior.webp",
    priceRange: "$325 to $585 and up",
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <Hero />
      <TrustBar />
      <Services />
      <Different />
      <Inspector />
      <ReportTeaser />
      <HowItWorks />
      <Pricing />
      <Reviews />
      <AgentsBand />
      <ServiceArea />
      <Faq />
      <Booking />
    </>
  );
}
