import { useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { site } from "../content/site";
import Lightbox from "../components/Lightbox";
import { Eyebrow, Reveal, SeverityPill, severityLabel, btnPrimary, container, usePageMeta } from "../components/ui-bits";

const filters = [
  { key: "all", label: "All" },
  { key: "safety", label: "Safety" },
  { key: "major", label: "Major" },
  { key: "moderate", label: "Moderate" },
  { key: "minor", label: "Minor" },
];

const countBorder = {
  safety: "border-l-severity-safety",
  major: "border-l-severity-major",
  moderate: "border-l-severity-moderate",
  minor: "border-l-severity-minor",
};

export default function SampleReportPage() {
  usePageMeta(
    "Sample Inspection Report | Ridgeline Home Inspections, Brandon FL",
    "A shortened sample home inspection report with photos, severity ratings, plain explanations and rough repair cost ranges."
  );
  const m = site.reportMeta;
  const [filter, setFilter] = useState("all");
  const [lightbox, setLightbox] = useState(null);
  const triggerRef = useRef(null);

  const counts = useMemo(() => {
    const c = { all: site.findings.length, safety: 0, major: 0, moderate: 0, minor: 0 };
    site.findings.forEach((f) => {
      c[f.severity] += 1;
    });
    return c;
  }, []);

  const visible = filter === "all" ? site.findings : site.findings.filter((f) => f.severity === filter);

  return (
    <>
      <section className="bg-paper pb-12 pt-14 md:pt-20" data-testid="report-header">
        <div className={container}>
          <Eyebrow>{m.eyebrow}</Eyebrow>
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <h1 className="text-[clamp(2.4rem,5vw,4rem)] font-bold leading-tight text-navy">{m.address}</h1>
              <p className="mt-3 max-w-2xl text-slate">{m.subline}</p>
            </div>
            <div className="space-y-1 text-sm text-slate">
              <p>{m.inspector}</p>
              <p>{m.delivered}</p>
            </div>
          </div>

          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4" data-testid="report-summary">
            {["safety", "major", "moderate", "minor"].map((k) => (
              <div key={k} className={`border-l-4 bg-white py-3 pl-4 pr-3 ${countBorder[k]}`}>
                <p className="font-heading text-2xl font-bold text-navy" data-testid={`count-${k}`}>
                  {counts[k]}
                </p>
                <p className="text-sm text-slate">{severityLabel(k)}</p>
              </div>
            ))}
          </div>
          <p className="mt-5 max-w-2xl text-sm text-slate">{m.summaryNote}</p>
        </div>
      </section>

      <div className="sticky top-[72px] z-30 border-y border-line bg-paper" data-testid="report-filter-bar">
        <div className={`${container} flex flex-wrap gap-2 py-3`} role="group" aria-label="Filter findings by severity">
          {filters.map((f) => (
            <button
              key={f.key}
              type="button"
              data-testid={`filter-${f.key}`}
              aria-pressed={filter === f.key}
              onClick={() => setFilter(f.key)}
              className={`rounded-md border px-4 py-2 text-sm font-semibold transition-colors duration-150 ${
                filter === f.key
                  ? "border-navy bg-navy text-white"
                  : "border-line bg-white text-ink hover:border-slate"
              }`}
            >
              {f.label} ({counts[f.key]})
            </button>
          ))}
        </div>
      </div>

      <section className="bg-white py-14 md:py-20" data-testid="findings-list">
        <div className={`${container} space-y-8`}>
          {visible.map((f) => {
            const n = site.findings.indexOf(f) + 1;
            return (
              <Reveal
                as="article"
                key={f.title}
                className="overflow-hidden rounded-lg border border-line bg-white transition-[border-color,box-shadow] duration-200 hover:border-[#C9C5BC] hover:shadow-[0_4px_14px_rgba(15,27,39,0.07)] lg:flex"
                data-testid={`finding-card-${n}`}
              >
                <button
                  type="button"
                  ref={triggerRef}
                  data-testid={`finding-photo-button-${n}`}
                  onClick={() => setLightbox({ src: f.photo, alt: f.alt, caption: `${f.area}: ${f.title}` })}
                  className="block shrink-0 cursor-zoom-in lg:w-[40%]"
                  aria-label={`Enlarge photo: ${f.title}`}
                >
                  <img
                    src={f.photo}
                    alt={f.alt}
                    width={1400}
                    height={1050}
                    loading="lazy"
                    className="aspect-[4/3] w-full object-cover transition-[filter] duration-200 hover:brightness-[0.97]"
                  />
                </button>
                <div className="flex-1 p-6 md:p-8">
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
                    <p className="text-xs font-semibold uppercase tracking-[0.12em] text-slate">{f.area}</p>
                    <SeverityPill severity={f.severity} testId={`finding-severity-${n}`} />
                    <p className="ml-auto text-xs text-slate">Finding {n} of {site.findings.length}</p>
                  </div>
                  <h2 className="mt-2.5 font-heading text-xl font-semibold leading-snug text-ink md:text-2xl">{f.title}</h2>
                  <dl className="mt-5 space-y-3.5">
                    {[
                      ["What we found", f.found],
                      ["Why it matters", f.why],
                      ["What to do", f.todo],
                      ["Rough cost range", f.cost],
                    ].map(([label, value]) => (
                      <div key={label} className="sm:flex sm:gap-4">
                        <dt className="w-36 shrink-0 text-sm font-semibold text-slate">{label}</dt>
                        <dd className="mt-0.5 text-[15px] leading-relaxed text-ink sm:mt-0">{value}</dd>
                      </div>
                    ))}
                  </dl>
                </div>
              </Reveal>
            );
          })}
        </div>
      </section>

      <section className="bg-paper py-16 md:py-20" data-testid="report-closing">
        <div className={container}>
          <Reveal>
            <h2 className="max-w-xl text-[clamp(1.8rem,3.2vw,2.6rem)] font-bold leading-tight text-navy">{m.closingTitle}</h2>
            <p className="mt-3 max-w-lg text-slate">{m.closingText}</p>
            <Link to="/#book" data-testid="report-book-button" className={`${btnPrimary} mt-7`}>
              {m.closingCta}
            </Link>
          </Reveal>
        </div>
      </section>

      {lightbox && (
        <Lightbox
          src={lightbox.src}
          alt={lightbox.alt}
          caption={lightbox.caption}
          onClose={() => setLightbox(null)}
          triggerRef={triggerRef}
        />
      )}
    </>
  );
}
