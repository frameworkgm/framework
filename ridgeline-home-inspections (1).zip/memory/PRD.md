# PRD: Ridgeline Home Inspections (design demo marketing site)

## Original problem statement
Build a complete, production-quality marketing website for a fictional home inspection company
("Ridgeline Home Inspections", Charlotte NC) as a design demo to show real home inspectors what
their own site could look like. Senior-designer quality, no AI/template look, plain-spoken copy,
real generated photography, three routes only (/, /sample-report, /agents), single content config
file, FastAPI + MongoDB backend storing two form types. Full spec delivered in the first user
message (sections 0-11).

## Architecture
- Frontend: React 19 + Tailwind + React Router 7, CRA/craco dev server on :3000
- Backend: FastAPI on :8001, MongoDB via motor (MONGO_URL / DB_NAME from env)
- Single content config: /app/frontend/src/content/site.js (all business copy, pricing, findings,
  reviews, FAQ, agent page text, service area, map dot positions)
- Pricing math: computeEstimate() in site.js, consumed by calculator and booking prefill
- Images: AI-generated (Gemini flash image model via emergentintegrations), script at
  /app/scripts/generate_images.py, saved to /app/frontend/public/images/*.webp

## User personas
- Home buyer/seller in Charlotte area researching an inspector
- Real estate agent booking inspections for clients
- Home inspector evaluating this demo as a template for their own business

## Core requirements (static)
- Exactly 3 routes, shared header/footer, hash links with sticky-header offset
- Home sections in fixed order: hero, trust bar, services, report teaser, how it works,
  pricing+calculator, reviews, agents band, service area, FAQ, booking
- Sample report: computed severity counters, sticky filter bar, finding cards with lightbox
- Agents page: hero, asymmetric benefit blocks, 4 steps, quote, request form, call band
- Calculator must match price table exactly; booking form prefill from calculator
- Backend: POST /api/bookings, POST /api/agent-requests (reference "RH-XXXXXX"), GET /api/health,
  honeypot rejection, server-side validation, CORS from env

## Implemented (2026-10-15)
- All three pages, all sections, all copy from spec
- Sticky header, mobile drawer (Escape, scroll lock), sticky mobile call/book bar
- Calculator: all 4 spec test cases pass ($425, $660, $375, $910), input clamping with messages
- Booking + agent forms: client validation, honeypot, reference numbers, stored in MongoDB
- Sample report filters (counts verified), lightbox (Escape, outside click, focus return)
- FAQ accordion (one open at a time, aria attributes)
- JSON-LD, per-page titles/descriptions, OG tags, SVG favicon + roofline wordmark
- Responsive verified at 375/768/1366, no horizontal scroll, no console errors
- 10 of 12 photos AI-generated and optimized (webp, q80)

## Round 2 edits (2026-10-15)
- Hero is now a full-width video slot (100vh-72px, min 620 max 860) with layered readability
  overlays, poster-until-playing crossfade, IntersectionObserver/visibility pause, reduced-motion
  and Save-Data poster fallback. VIDEO NOT GENERATED: Fal video generation returned 402
  (Integration Wallet balance 0 ECU). Slot waits for /public/videos/hero.mp4 + hero.webm;
  poster is /images/hero-exterior.webp. Generator script: /app/scripts/generate_video.py
  (Hailuo-02 10s via fal proxy, ffmpeg loop crossfade, mp4+webm+poster export).
- Location re-branded to Brandon, FL everywhere (config first; page titles, meta, OG, JSON-LD
  with geo 27.9378/-82.2859 and postalCode 33511, map dots rebuilt with 12 Tampa Bay cities).
- Services: 10 items (added 4-Point, wind mitigation, thermal imaging; removed mold air sampling).
  Add-ons: mold out, 4-Point $150 + wind mitigation $100 in. Calculator case 5 verified = $675.
  Booking form add-ons and backend accept new ids (backend never whitelisted names).
- FAQ rebuilt: search field, category sidebar/tabs (All + 5 categories, 24 items), grouped
  accordion with 250ms height animation, live result count region, no-match message, navy CTA
  block, FAQPage JSON-LD (24 Q/A).
- New #different section (What makes us different?) after Services; "Why us" nav item added.
- Motion system: cubic-bezier(0.22,1,0.36,1) everywhere, no delays, reveal 350ms/10px/15%
  threshold gated behind html.js (content visible without JS), button hovers are color-only,
  drawer slides 250ms with dim, lightbox/success fade 200ms, header border darkens on scroll,
  desktop section padding 112px, eyebrow tracking 0.14em.
- Fixed overflow regressions found in verification: drawer clipped with overflow-hidden,
  FAQ grid columns got min-w-0.

## Round 3 bug fixes (2026-10-15)
- Calculator + booking numeric inputs rewritten: raw string state, digits-only sanitizing,
  leading-zero strip, length caps, blur/Enter validation with inline messages, last-valid
  restore on empty, estimate hidden until both fields valid, Book button corrects and focuses
  invalid fields before prefilling. All 5 calculator cases re-verified exact.
- Service area stylized map replaced with real Google Maps iframe embed (config-driven URLs),
  "Tap to use the map" overlay below 1024px to prevent the mobile scroll trap. Fixed a
  1024px-only overflow caused by aspect-ratio transferring min-height into width (added w-full).
- Mobile drawer: always mounted, fixed right off-canvas with translate3d transform-only 250ms
  animation, overlay opacity-only with delayed visibility, will-change on both from load,
  100dvh height, scroll lock on html+body, focus trap + focus return, z-order header 40 /
  bar 30 / overlay 60 / drawer 70, hero video pauses while drawer open. First-open verified
  animating under 4x CPU throttle.

## Round 4 upgrades (2026-10-16)
- Demo notice bar above the header (navy, config-driven demoNotice) with "Request your site"
  CTA linking to /#book. Non-sticky so header height and hash offsets stay unchanged.
- Glassmorphism on the sticky header after scroll (bg-white/85 + backdrop-blur-md).
- Subtle micro-interactions on cards (border + soft shadow, 200ms, global easing) on reviews,
  finding cards, teaser cards, calculator card; service icons shift to accent on row hover.
- Agents page: new ROI block (agentsRoi config) with outlined "3x" numeral, "How much time
  does a poor report cost you?" heading and three proof points.
- Home: new "Meet your inspector" section after #different (inspector config), with a
  generated face-free field photo (/public/images/inspector-ladder.webp; first attempt had a
  duplicated-person artifact, second had a synthetic look the user rejected; final version is a
  wide documentary shot of one inspector on a ladder, verified artifact-free).
- Verified: no overflow at 375/768/1024/1440, no console errors, drawer first-open still
  animates smoothly, all prior functionality intact.

## Known gaps
- Hero video files not present (see Round 2 notes): slot is live, poster shows, video fades in
  once hero.mp4/hero.webm are added to /app/frontend/public/videos/.
- Primary buttons use ink text on accent (WCAG AA) instead of spec's white text.

## Resolved
- 2026-10-15: finding-foundation-crack.webp and finding-grading.webp were temporarily flat
  placeholders after the LLM key image budget ran out; regenerated as real photos after the
  user topped up credits. All 12 photos are now AI-generated.

## Backlog
- P0: None
- P1: None
- P2: None requested; spec forbids extra features
