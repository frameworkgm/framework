# Test Credentials
# Agent writes here when creating/modifying auth credentials (admin accounts, test users).
# Testing agent reads this before auth tests. Fork/continuation agents read on startup.

No authentication in this app. No user accounts, no admin panel.

Test data for manual form checks:
- Booking form (/#book): any values; date must be today or later. Reference format RH-XXXXXX.
- Agent form (/agents#agent-form): any values; same date rule.
- Honeypot field name: "website" (hidden; filling it returns a reference without storing).
