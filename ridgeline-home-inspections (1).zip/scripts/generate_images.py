import asyncio
import base64
import io
import os

from dotenv import load_dotenv

load_dotenv("/app/backend/.env")

from emergentintegrations.llm.chat import LlmChat, UserMessage
from PIL import Image

OUT = "/app/frontend/public/images"

STYLE = (
    "Documentary inspection photography. Looks like it was taken by a working home inspector "
    "with a recent smartphone or a mid-range DSLR, not by a stock photographer. Natural light, "
    "or flashlight or on-camera flash where appropriate. Slightly uneven exposure, true-to-life "
    "muted colors, visible dust, dirt, wear and age, small asymmetries, ordinary real-world "
    "clutter. NOT glossy, NOT HDR, NOT oversaturated, NOT cinematic, NOT airbrushed, no "
    "plastic-smooth surfaces, no perfect symmetry, no dramatic bokeh, no teal-and-orange grading. "
    "No people or faces. No hands. No readable text, logos, brand names or labels anywhere in the "
    "frame (any labels must be absent or unreadable). No watermarks. Realistic proportions, "
    "correct geometry, correct materials."
)

IMAGES = [
    ("hero-exterior.webp", (3, 2), 1920,
     "A typical two-story American suburban house with a front-gable asphalt shingle roof, light gray "
     "fiber-cement siding, a brick front porch base, a two-car garage and a small lawn. Taken from the "
     "street at a slight angle on an overcast mid-morning, soft even light. A mid-size white pickup truck "
     "with a roof-mounted ladder rack and a ladder is parked in the driveway, no lettering on it. Slightly "
     "worn driveway, a couple of ordinary shrubs, a mailbox. Ordinary and believable, not a luxury listing photo."),
    ("thermal-scan.webp", (4, 3), 1400,
     "A real-looking thermal camera screenshot of an interior wall and ceiling corner, standard ironbow "
     "palette (purple to orange to yellow), with one cooler blue-purple irregular patch on the ceiling "
     "suggesting moisture or missing insulation. Include the typical thermal camera on-screen crosshair and "
     "a temperature scale bar, but with NO readable numbers or text (blur or omit digits). Low resolution "
     "look, slightly soft, like real thermal output."),
    ("finding-roof-shingles.webp", (4, 3), 1400,
     "Close-up of an asphalt shingle roof slope in daylight showing granule loss in the lower third, a few "
     "lifted and slightly curled tabs, moss streaks near the edge, aged gray-brown shingles."),
    ("finding-chimney-flashing.webp", (4, 3), 1400,
     "A brick chimney meeting an asphalt roof, with rusted step flashing along one side and dark, cracked "
     "sealant at the base, slight staining on the brick below the flashing."),
    ("finding-attic-insulation.webp", (4, 3), 1400,
     "Attic floor photographed with a flashlight, showing uneven, compressed blown-in insulation about 4 "
     "inches deep, bare spots between joists, visible wood joists, a few cobwebs and dust, dim lighting "
     "with a bright flashlight hotspot."),
    ("finding-ceiling-stain.webp", (4, 3), 1400,
     "A white bathroom ceiling with an irregular tan-brown water stain about 14 inches wide near a light "
     "fixture, slightly bubbled paint at the edge, ordinary bathroom with a corner of a white fan housing "
     "visible. Harsh overhead bathroom light, phone-camera look."),
    ("finding-electrical-panel.webp", (4, 3), 1400,
     "An open gray residential breaker panel with the cover removed, taken with on-camera flash, showing "
     "several breakers with two wires clamped under a single breaker screw and one empty knockout hole in "
     "the enclosure. Wires are black, white and bare copper, slightly dusty. No readable labels or handwriting."),
    ("finding-kitchen-outlet.webp", (4, 3), 1400,
     "A standard white duplex wall outlet on a kitchen backsplash about two feet from a stainless sink edge, "
     "no test or reset buttons (a regular outlet, not a GFCI), slightly yellowed plate, normal kitchen "
     "under-cabinet lighting."),
    ("finding-water-heater.webp", (4, 3), 1400,
     "A white 40-gallon tank water heater in a garage corner, no drain pan underneath, a copper discharge "
     "pipe that ends short about 8 inches above the floor, slightly dusty and rusty at the base, concrete "
     "floor, ordinary garage clutter at the edge of the frame. No readable data plate text."),
    ("finding-foundation-crack.webp", (4, 3), 1400,
     "A hairline crack in a gray concrete garage slab near a corner where it meets a block wall, about as "
     "thin as a pencil line with slight stair-step along a joint, a few oil stains and dust on the slab, "
     "shot at a low angle in daylight from the open garage door."),
    ("finding-hvac-condenser.webp", (4, 3), 1400,
     "An outdoor air conditioner condenser unit beside a house, coil fins clogged with leaves and cottonwood "
     "fluff, a few bent fins, rust at the base, standing on a slightly tilted gray pad, grass clippings "
     "around it, side of a house with siding behind it."),
    ("finding-grading.webp", (4, 3), 1400,
     "The side of a house with soil sloping toward the foundation, splash marks and mud staining on the "
     "lower siding, a downspout that ends right at the wall with no extension, patchy grass and a bit of "
     "mulch, overcast daylight."),
]


async def generate(name, ratio, max_width, prompt, attempt):
    chat = LlmChat(
        api_key=os.environ["EMERGENT_LLM_KEY"],
        session_id=f"ridgeline-{name}-{attempt}",
        system_message="You generate photorealistic documentary photographs exactly as described.",
    )
    chat.with_model("gemini", "gemini-3.1-flash-image-preview").with_params(modalities=["image", "text"])
    msg = UserMessage(text=f"{prompt}\n\n{STYLE}\n\nAspect ratio {ratio[0]}:{ratio[1]}.")
    _, images = await chat.send_message_multimodal_response(msg)
    if not images:
        raise RuntimeError("no image returned")
    raw = base64.b64decode(images[0]["data"])
    img = Image.open(io.BytesIO(raw)).convert("RGB")
    tw, th = ratio
    target = tw / th
    w, h = img.size
    if w / h > target:
        nw = int(h * target)
        x = (w - nw) // 2
        img = img.crop((x, 0, x + nw, h))
    else:
        nh = int(w / target)
        y = (h - nh) // 2
        img = img.crop((0, y, w, y + nh))
    if img.width > max_width:
        img = img.resize((max_width, int(max_width / target)), Image.LANCZOS)
    img.save(os.path.join(OUT, name), "WEBP", quality=80)
    print(f"OK {name} {img.size}", flush=True)


async def main():
    os.makedirs(OUT, exist_ok=True)
    for name, ratio, max_width, prompt in IMAGES:
        done = False
        for attempt in range(2):
            try:
                await generate(name, ratio, max_width, prompt, attempt)
                done = True
                break
            except Exception as e:
                print(f"ERR {name} attempt {attempt}: {type(e).__name__}: {e}", flush=True)
        if not done:
            print(f"FAILED {name}", flush=True)
    print("ALL DONE", flush=True)


asyncio.run(main())
