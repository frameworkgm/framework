import os
import re
import subprocess
import time

import imageio_ffmpeg
import requests
from dotenv import load_dotenv
from PIL import Image

load_dotenv("/app/backend/.env")

KEY = os.environ["EMERGENT_LLM_KEY"]
BASE = os.environ.get("INTEGRATION_PROXY_URL", "https://integrations.emergentagent.com").rstrip("/")
CONTROL = f"{BASE}/api/v1/fal"
H = {"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"}
ENDPOINT = "fal-ai/minimax/hailuo-02/standard/text-to-video"
FFMPEG = imageio_ffmpeg.get_ffmpeg_exe()
OUTDIR = "/app/frontend/public/videos"
RAW = "/tmp/hero-raw.mp4"

PROMPT = (
    "Aerial drone footage gliding slowly forward and very slightly descending over the asphalt shingle "
    "roof of a single-family suburban home in Florida. Stucco walls, part of a backyard with a screened "
    "lanai and a pool visible, a few palm trees and neighboring rooftops, a clear but slightly hazy "
    "morning sky, soft natural light. Steady, stabilized consumer drone movement, slow and smooth, no "
    "fast pans, no zooms, no whip effects. Real footage look, natural muted colors, no oversaturation, "
    "no cinematic color grading, no fisheye, no CGI feel. No people, no cars with readable plates, no "
    "text, no logos, no watermarks."
)


def log(*a):
    print(*a, flush=True)


r = requests.post(
    f"{CONTROL}/proxy",
    headers={**H, "X-Fal-Target-Url": f"https://queue.fal.run/{ENDPOINT}"},
    json={"prompt": PROMPT, "duration": "10"},
    timeout=60,
)
log("submit", r.status_code)
r.raise_for_status()
sub = r.json()
status_url, response_url = sub["status_url"], sub["response_url"]

deadline = time.monotonic() + 900
res = None
while time.monotonic() < deadline:
    s = requests.get(status_url, headers=H, timeout=30).json()
    st = (s.get("status") or "").upper()
    log("status", st)
    if st in ("COMPLETED", "OK"):
        res = requests.get(response_url, headers=H, timeout=60).json()
        break
    if st in ("FAILED", "CANCELLED", "CANCELED", "ERROR"):
        raise RuntimeError(f"generation failed: {st}")
    time.sleep(3)
if res is None:
    raise RuntimeError("timed out waiting for video")

vurl = (res.get("video") or {}).get("url") or res.get("video_url")
if not vurl:
    raise RuntimeError(f"no video url in result: {list(res.keys())}")
vid = requests.get(vurl, timeout=300)
open(RAW, "wb").write(vid.content)
log("downloaded bytes", len(vid.content))

p = subprocess.run([FFMPEG, "-i", RAW], capture_output=True, text=True)
m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", p.stderr)
L = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
log("duration", L)
d = 0.6
off = max(L - d, 0.1)

os.makedirs(OUTDIR, exist_ok=True)
filt = (
    f"[0:v]scale=1920:1080:force_original_aspect_ratio=increase:flags=lanczos,crop=1920:1080,"
    f"fps=30,format=yuv420p,split[m][n];[m]trim=end={off:.2f},setpts=PTS-STARTPTS[mm];"
    f"[mm][n]xfade=transition=fade:duration={d}:offset={off:.2f}[v]"
)
for crf in (26, 30, 34):
    subprocess.run(
        [FFMPEG, "-y", "-i", RAW, "-filter_complex", filt, "-map", "[v]", "-c:v", "libx264",
         "-crf", str(crf), "-preset", "medium", "-pix_fmt", "yuv420p", "-movflags", "+faststart",
         "-an", f"{OUTDIR}/hero.mp4"],
        capture_output=True,
    )
    size = os.path.getsize(f"{OUTDIR}/hero.mp4")
    log("mp4 crf", crf, "bytes", size)
    if size < 4_900_000:
        break

enc = subprocess.run([FFMPEG, "-encoders"], capture_output=True, text=True).stdout
if "libvpx-vp9" in enc:
    subprocess.run(
        [FFMPEG, "-y", "-i", f"{OUTDIR}/hero.mp4", "-c:v", "libvpx-vp9", "-crf", "34", "-b:v", "0",
         "-an", f"{OUTDIR}/hero.webm"],
        capture_output=True,
    )
    log("webm bytes", os.path.getsize(f"{OUTDIR}/hero.webm"))
else:
    log("NO VP9 ENCODER")

subprocess.run([FFMPEG, "-y", "-i", f"{OUTDIR}/hero.mp4", "-frames:v", "1", "/tmp/hero-poster.png"], capture_output=True)
Image.open("/tmp/hero-poster.png").convert("RGB").save("/app/frontend/public/images/hero-poster.webp", "WEBP", quality=80)
log("DONE")
